# 无线烧录已验证版本 — 2026-10-23 18:38

新 F407VET6，512 KiB、RDP=AA。原工程 8880 字节通过主机 USB → ESP-NOW → 从机 SWD 写入、完整读回、启动确认，任务 ccceb936d25638e73bdc59c1，重试 0 次，任务约12.44秒。

sources/ 保留本次验收时的主从固件、共享库、电脑后台/Keil 适配器和 STM32 工程源码；binaries/ 保留目标镜像、从机镜像及其上次 USB 写入校验记录，并附主机本地编译产物；evidence/ 保留本次完整任务证据。MANIFEST.json 列出每个文件的 SHA256。

从机使用 slave_flash_psram、16MB Flash/8MB Octal PSRAM；主机使用 host_flash。sources 下的 ESP32 工程和 PID_Shared 必须保持同级目录。ESP 固件的 bootloader/partitions/boot_app0/app 地址分别为 0x0/0x8000/0xE000/0x10000；这些地址只适用于该 ESP32 配置，不是 STM32 地址。目标 STM32 镜像地址为0x08000000，不能互相混烧。

本次没有刷写两块 ESP32，也没有解除新目标读保护。从机 BIN 的哈希与最近一次成功 USB 写入记录一致；主机 BIN 是磁盘本地编译产物，未独立读取主机 Flash，不将它冒充实板 Flash 备份。

Keil 工程当前保留 ST-Link 有线 Download 配置；本次无线验收直接调用 pid_keil.py。不要将恢复 Keil 项目配置与恢复 ESP 固件混为一项操作。恢复前先保存当前源码和配置，按硬件型号、USB序列号确认身份；不要自动解除读保护或重复擦除。

旧 F407 的 RDP=FF 异常没有在新目标复现，旧目标具体原因尚未独立确认。本包用于保存已验证版本，不承诺任意其他硬件可直接套用。
