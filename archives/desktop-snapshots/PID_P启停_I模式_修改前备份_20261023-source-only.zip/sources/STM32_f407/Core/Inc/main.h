/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Motor_A_PWMA_Pin GPIO_PIN_0
#define Motor_A_PWMA_GPIO_Port GPIOA
#define Motor_B_PWMB_Pin GPIO_PIN_1
#define Motor_B_PWMB_GPIO_Port GPIOA
#define Motor_A_AIN1_Pin GPIO_PIN_4
#define Motor_A_AIN1_GPIO_Port GPIOA
#define Motor_A_AIN2_Pin GPIO_PIN_5
#define Motor_A_AIN2_GPIO_Port GPIOA
#define Motor_B_BIN1_Pin GPIO_PIN_6
#define Motor_B_BIN1_GPIO_Port GPIOA
#define Motor_B_BIN2_Pin GPIO_PIN_7
#define Motor_B_BIN2_GPIO_Port GPIOA
#define Motor_A_E1A_Pin GPIO_PIN_12
#define Motor_A_E1A_GPIO_Port GPIOD
#define Motor_A_E1B_Pin GPIO_PIN_13
#define Motor_A_E1B_GPIO_Port GPIOD
#define YELLOW_Pin GPIO_PIN_8
#define YELLOW_GPIO_Port GPIOA
#define USART1_TX_Pin GPIO_PIN_9
#define USART1_TX_GPIO_Port GPIOA
#define USART1_RX_Pin GPIO_PIN_10
#define USART1_RX_GPIO_Port GPIOA
#define Motor_B_E2A_Pin GPIO_PIN_4
#define Motor_B_E2A_GPIO_Port GPIOB
#define Motor_B_E2B_Pin GPIO_PIN_5
#define Motor_B_E2B_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
