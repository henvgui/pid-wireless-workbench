#include <Arduino.h>
#include <Adafruit_NeoPixel.h>

#if !defined(CONFIG_IDF_TARGET_ESP32S3) || ARDUINO_USB_MODE != 1 || ARDUINO_USB_CDC_ON_BOOT != 1
#error "Select ESP32-S3 with native hardware USB CDC enabled."
#endif

namespace {
// 模组第 24 脚是 GPIO47；Arduino 的引脚参数使用 GPIO 编号。
constexpr uint8_t RGB_PIN = 47;
constexpr uint16_t LED_COUNT = 40;
constexpr uint8_t BRIGHTNESS = 48;  // 0~255，约 19%。
constexpr uint32_t STEP_MS = 100;   // 每 100ms 前进一步。

struct RGB {
  uint8_t red;
  uint8_t green;
  uint8_t blue;
};

constexpr RGB COLORS[] = {{255, 0, 0}, {0, 255, 0}, {0, 0, 255}};
constexpr uint8_t TRAIL_LEVELS[] = {255, 112, 48, 16};
constexpr uint8_t COLOR_COUNT = sizeof(COLORS) / sizeof(COLORS[0]);

// XL-5050RGBC-2812B-S：单线 800kbit/s，GRB 顺序。
Adafruit_NeoPixel strip(LED_COUNT, RGB_PIN, NEO_GRB + NEO_KHZ800);
uint16_t head = 0;
uint8_t colorIndex = 0;
uint32_t lastStepMs = 0;
uint32_t frameCount = 0;

uint8_t scale(uint8_t channel, uint8_t level) {
  return static_cast<uint16_t>(channel) * level / 255;
}

void renderFrame() {
  strip.clear();
  const RGB color = COLORS[colorIndex];
  for (uint8_t tail = 0; tail < sizeof(TRAIL_LEVELS); ++tail) {
    const uint16_t pixel = (head + LED_COUNT - tail) % LED_COUNT;
    const uint8_t level = TRAIL_LEVELS[tail];
    strip.setPixelColor(pixel, scale(color.red, level),
                       scale(color.green, level), scale(color.blue, level));
  }
  strip.show();
  ++frameCount;
}

void serviceUSB() {
  // 保留文本回显；发 '?' 可查看流水灯程序的运行状态。
  // 限制每轮处理量，持续发送数据时灯效也能继续运行。
  for (uint8_t received = 0; received < 64 && Serial.available() > 0; ++received) {
    const int value = Serial.read();
    if (value < 0) {
      break;
    }
    if (value == '?') {
      Serial.printf("\nRGB_CHASE pin=%u leds=%u frames=%lu head=%u uptime_ms=%lu\n",
                    static_cast<unsigned>(RGB_PIN),
                    static_cast<unsigned>(LED_COUNT),
                    static_cast<unsigned long>(frameCount),
                    static_cast<unsigned>(head),
                    static_cast<unsigned long>(millis()));
    } else {
      Serial.write(static_cast<uint8_t>(value));
    }
  }
}
}  // namespace

void setup() {
  // 不初始化 Wi-Fi、蓝牙；Serial 使用原生 USB。
  Serial.begin(115200);
  Serial.setDebugOutput(false);
  strip.begin();
  strip.setBrightness(BRIGHTNESS);
  renderFrame();
  lastStepMs = millis();
}

void loop() {
  serviceUSB();
  const uint32_t now = millis();
  if (now - lastStepMs >= STEP_MS) {
    lastStepMs = now;
    if (++head >= LED_COUNT) {
      head = 0;
      colorIndex = (colorIndex + 1) % COLOR_COUNT;
    }
    renderFrame();
  }
  delay(1);
}
