#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <math.h>

#if !defined(CONFIG_IDF_TARGET_ESP32S3) || ARDUINO_USB_MODE != 1 || ARDUINO_USB_CDC_ON_BOOT != 1
#error "Select ESP32-S3 with native hardware USB CDC enabled."
#endif

namespace {
// 模组第 24 脚是 GPIO47；灯的位置按数据串联顺序计数。
constexpr uint8_t RGB_PIN = 47;
constexpr uint16_t LED_COUNT = 40;
constexpr uint8_t BRIGHTNESS = 40;  // 全局上限约 16%，避免全部灯高亮白色。
constexpr uint32_t FRAME_MS = 16;
constexpr uint32_t EFFECT_MS = 8000;
constexpr uint32_t TRANSITION_MS = 1000;
constexpr uint8_t EFFECT_COUNT = 8;
constexpr float TAU = 6.28318530718f;
constexpr const char* EFFECT_NAMES[EFFECT_COUNT] = {
    "rainbow_flow", "twin_comets", "aurora", "scanner",
    "rainbow_chase", "ripples", "fire", "starfield"};

Adafruit_NeoPixel strip(LED_COUNT, RGB_PIN, NEO_GRB + NEO_KHZ800);
uint32_t lastFrameMs = 0;
uint32_t frameCount = 0;

struct RGB {
  float r;
  float g;
  float b;
};

float clamp01(float x) {
  return fminf(1.0f, fmaxf(0.0f, x));
}

float wrap(float x, float length) {
  return x - floorf(x / length) * length;
}

float wave(float phase) {
  return 0.5f + 0.5f * sinf(phase);
}

RGB scaled(RGB color, float level) {
  return {color.r * level, color.g * level, color.b * level};
}

RGB add(RGB a, RGB b) {
  return {a.r + b.r, a.g + b.g, a.b + b.b};
}

RGB mix(RGB a, RGB b, float weight) {
  return {a.r + (b.r - a.r) * weight,
          a.g + (b.g - a.g) * weight,
          a.b + (b.b - a.b) * weight};
}

RGB hue(float position) {
  const uint32_t color = Adafruit_NeoPixel::ColorHSV(
      static_cast<uint16_t>(wrap(position, 1.0f) * 65535.0f));
  return {static_cast<float>((color >> 16) & 255) / 255.0f,
          static_cast<float>((color >> 8) & 255) / 255.0f,
          static_cast<float>(color & 255) / 255.0f};
}

uint32_t hash(uint32_t value) {
  value ^= value >> 16;
  value *= 0x7feb352dU;
  value ^= value >> 15;
  value *= 0x846ca68bU;
  return value ^ (value >> 16);
}

float noise(uint32_t seed) {
  return static_cast<float>(hash(seed) & 65535U) / 65535.0f;
}

float cometTail(float distance, float length) {
  const float level = clamp01(1.0f - distance / length);
  return level * level;
}

RGB effectPixel(uint8_t effect, uint16_t pixel, uint32_t now) {
  const float t = static_cast<float>(now) * 0.001f;
  const float x = static_cast<float>(pixel);
  const float u = x / static_cast<float>(LED_COUNT);

  switch (effect) {
    case 0: {  // 彩虹流水：色带旋转，同时有柔和明暗波。
      const float level = 0.25f + 0.75f * wave(u * TAU * 2.0f - t * 3.0f);
      return scaled(hue(u * 1.5f - t * 0.15f), level);
    }
    case 1: {  // 两颗反向运动的彗星，带彩色拖尾。
      const float a = wrap(t * 13.0f, LED_COUNT);
      const float b = wrap(-t * 10.0f + LED_COUNT * 0.5f, LED_COUNT);
      RGB color = scaled(hue(u + t * 0.05f), 0.025f);
      color = add(color, scaled(hue(t * 0.08f),
                                cometTail(wrap(a - x, LED_COUNT), 11.0f)));
      return add(color, scaled(hue(t * 0.08f + 0.5f),
                               cometTail(wrap(x - b, LED_COUNT), 9.0f)));
    }
    case 2: {  // 极光：青绿、蓝紫光带以不同速度叠加。
      const float green = wave(u * TAU * 2.0f - t * 1.4f);
      const float violet = wave(u * TAU * 3.0f + t * 0.9f);
      const float blue = wave(u * TAU - t * 0.7f);
      return {0.4f * violet * violet, 0.9f * green * green,
              0.2f + 0.55f * blue + 0.25f * violet};
    }
    case 3: {  // 往返扫描：两条光带交会，端点自然反向。
      const float head = wave(t * 2.1f - TAU * 0.25f) * (LED_COUNT - 1);
      const float first = cometTail(fabsf(x - head), 7.0f);
      const float second = cometTail(fabsf(x - (LED_COUNT - 1 - head)), 5.0f);
      return add(scaled(hue(t * 0.09f), first),
                 scaled(hue(t * 0.09f + 0.45f), second * 0.7f));
    }
    case 4: {  // 彩虹追逐：亮点穿过低亮度背景色带。
      const float distance = wrap(x - t * 14.0f, 5.0f);
      const float level = 0.06f + 0.94f * cometTail(distance, 2.2f);
      return scaled(hue(u - t * 0.12f), level);
    }
    case 5: {  // 多点涟漪：彩色波纹向两侧扩散。
      RGB color = {0.0f, 0.0f, 0.0f};
      for (uint8_t source = 0; source < 3; ++source) {
        const float origin = (source + 0.5f) * LED_COUNT / 3.0f;
        const float age = wrap(t + source * 1.1f, 3.5f);
        const float ring = cometTail(fabsf(fabsf(x - origin) - age * 10.0f), 2.5f);
        color = add(color, scaled(hue(t * 0.06f + source / 3.0f),
                                  ring * (1.0f - age / 4.0f)));
      }
      return color;
    }
    case 6: {  // 火焰流：平滑噪声组成橙红流动和金色火星。
      const uint32_t tick = now / 90;
      const float fraction = static_cast<float>(now % 90) / 90.0f;
      const float flicker = noise(pixel * 137U + tick * 911U) * (1.0f - fraction)
                          + noise(pixel * 137U + (tick + 1) * 911U) * fraction;
      const float heat = clamp01(0.2f + 0.5f * wave(u * TAU * 2.0f - t * 4.0f)
                                + flicker * 0.45f);
      return {heat, heat * heat * 0.6f, heat * heat * heat * 0.045f};
    }
    default: {  // 星空：每颗灯独立呼吸，彩色星点叠加白色亮芯。
      const uint32_t seed = hash(pixel * 1237U + 17U);
      const float frequency = 0.2f + 0.25f * noise(seed);
      const float phase = wrap(t * frequency + noise(seed + 1U), 1.0f);
      const float pulse = sinf(phase * TAU * 0.5f);
      const float twinkle = pulse * pulse * pulse * pulse * pulse * pulse;
      const RGB star = mix(hue(noise(seed + 2U) + t * 0.03f), {1, 1, 1},
                           twinkle * twinkle * 0.55f);
      return scaled(star, 0.015f + twinkle * 0.95f);
    }
  }
}

uint8_t channel(float value) {
  // Gamma 校正让渐变和拖尾在低亮度时更自然。
  return Adafruit_NeoPixel::gamma8(static_cast<uint8_t>(clamp01(value) * 255.0f));
}

void renderFrame(uint32_t now) {
  const uint8_t current = (now / EFFECT_MS) % EFFECT_COUNT;
  const uint32_t localTime = now % EFFECT_MS;
  const bool transitioning = localTime >= EFFECT_MS - TRANSITION_MS;
  float blend = transitioning
      ? static_cast<float>(localTime - (EFFECT_MS - TRANSITION_MS)) / TRANSITION_MS
      : 0.0f;
  blend = blend * blend * (3.0f - 2.0f * blend);

  for (uint16_t pixel = 0; pixel < LED_COUNT; ++pixel) {
    RGB color = effectPixel(current, pixel, now);
    if (transitioning) {
      color = mix(color, effectPixel((current + 1) % EFFECT_COUNT, pixel, now), blend);
    }
    strip.setPixelColor(pixel, channel(color.r), channel(color.g), channel(color.b));
  }
  strip.show();
  ++frameCount;
}

void serviceUSB() {
  bool replied = false;
  for (uint8_t received = 0; received < 64 && Serial.available() > 0; ++received) {
    const int value = Serial.read();
    if (value < 0) {
      break;
    }
    if (value == '?') {
      const uint32_t now = millis();
      const uint8_t current = (now / EFFECT_MS) % EFFECT_COUNT;
      Serial.printf("\nRGB_SHOW pin=%u leds=%u brightness=%u effect=%u name=%s "
                    "frames=%lu uptime_ms=%lu\n",
                    static_cast<unsigned>(RGB_PIN), static_cast<unsigned>(LED_COUNT),
                    static_cast<unsigned>(BRIGHTNESS), static_cast<unsigned>(current),
                    EFFECT_NAMES[current], static_cast<unsigned long>(frameCount),
                    static_cast<unsigned long>(now));
      replied = true;
    } else {
      Serial.write(static_cast<uint8_t>(value));
      replied = true;
    }
  }
  if (replied) {
    // 先完成 USB 回复，再开始下一帧灯光输出。
    Serial.flush();
  }
}
}  // namespace

void setup() {
  // 不初始化 Wi-Fi、蓝牙；保留原生 USB 文本回显。
  Serial.begin(115200);
  Serial.setDebugOutput(false);
  strip.begin();
  strip.setBrightness(BRIGHTNESS);
  lastFrameMs = millis();
  renderFrame(lastFrameMs);
}

void loop() {
  serviceUSB();
  const uint32_t now = millis();
  if (now - lastFrameMs >= FRAME_MS) {
    lastFrameMs = now;
    renderFrame(now);
  }
  delay(1);
}
