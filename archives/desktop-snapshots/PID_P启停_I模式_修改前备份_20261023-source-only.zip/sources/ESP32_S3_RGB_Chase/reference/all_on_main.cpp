#include <Arduino.h>
#include <Adafruit_NeoPixel.h>

#if !defined(CONFIG_IDF_TARGET_ESP32S3) || ARDUINO_USB_MODE != 1 || ARDUINO_USB_CDC_ON_BOOT != 1
#error "Select ESP32-S3 with native hardware USB CDC enabled."
#endif

namespace {
// 模组第 24 脚是 GPIO47；Arduino 的引脚参数使用 GPIO 编号。
constexpr uint8_t RGB_PIN = 47;
constexpr uint16_t LED_COUNT = 40;
constexpr uint8_t BRIGHTNESS = 16;  // 0~255，全部灯先用约 6% 亮度。
constexpr uint32_t REFRESH_MS = 1000;

// XL-5050RGBC-2812B-S：单线 800kbit/s，GRB 顺序。
Adafruit_NeoPixel strip(LED_COUNT, RGB_PIN, NEO_GRB + NEO_KHZ800);
uint32_t lastStepMs = 0;
uint32_t frameCount = 0;

void renderFrame() {
  // 所有 40 颗同时显示白色，定期重发同一帧以保持常亮。
  strip.fill(strip.Color(255, 255, 255));
  strip.show();
  ++frameCount;
}

void serviceUSB() {
  // 保留文本回显；发 '?' 可查看全部常亮程序的运行状态。
  // 限制每轮处理量，持续发送数据时灯效也能继续运行。
  for (uint8_t received = 0; received < 64 && Serial.available() > 0; ++received) {
    const int value = Serial.read();
    if (value < 0) {
      break;
    }
    if (value == '?') {
      Serial.printf("\nRGB_ALL_ON pin=%u leds=%u brightness=%u frames=%lu uptime_ms=%lu\n",
                    static_cast<unsigned>(RGB_PIN),
                    static_cast<unsigned>(LED_COUNT),
                    static_cast<unsigned>(BRIGHTNESS),
                    static_cast<unsigned long>(frameCount),
                    static_cast<unsigned long>(millis()));
    } else {
      Serial.write(static_cast<uint8_t>(value));
    }
  }
}
}  // namespace

void setup() {
  // 不初始化 Wi-Fi、蓝牙；Serial 使用原生 USB。
  Serial.begin(115200);
  Serial.setDebugOutput(false);
  strip.begin();
  strip.setBrightness(BRIGHTNESS);
  renderFrame();
  lastStepMs = millis();
}

void loop() {
  serviceUSB();
  const uint32_t now = millis();
  if (now - lastStepMs >= REFRESH_MS) {
    lastStepMs = now;
    renderFrame();
  }
  delay(1);
}
