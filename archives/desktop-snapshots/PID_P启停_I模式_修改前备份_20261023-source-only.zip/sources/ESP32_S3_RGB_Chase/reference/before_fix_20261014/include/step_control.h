#pragma once
#include <stdint.h>
#include "rgb_show.h"

#ifdef ARDUINO
#include "esp_attr.h"
#define STEP_ISR_ATTR IRAM_ATTR
#else
#define STEP_ISR_ATTR
#endif

namespace stepcontrol {
constexpr uint8_t kPinA = 15;
constexpr uint8_t kPinB = 16;
constexpr uint8_t kPinSwitch = 17;
constexpr uint8_t kPaletteCount = 8;
constexpr uint8_t kTrailLength = 7;
constexpr uint32_t kButtonDebounceMs = 25;
constexpr uint8_t kKnobCount = 4;
struct KnobPins {
  const char* name;
  uint8_t a, b, sw;
  uint16_t position;
  uint8_t color;
};
extern const KnobPins kKnobs[kKnobCount];
struct Rgb { uint8_t r, g, b; };
extern const char* const kColorNames[kPaletteCount];

// Call under the same critical section from the ISR and the main loop.
// One-bit Gray transitions cancel contact bounce; diagonal jumps are discarded.
class Quadrature {
 public:
  void begin(uint8_t ab, uint8_t edges = 4) {
    previous_ = ab & 3;
    accumulator_ = 0;
    edges_ = edges;
    invalid_ = 0;
  }
  int8_t STEP_ISR_ATTR onEdge(uint8_t ab) {
    ab &= 3;
    const uint8_t changed = previous_ ^ ab;
    if (!changed) return 0;
    if (changed == 3) {
      previous_ = ab;
      accumulator_ = 0;
      ++invalid_;
      return 0;
    }
    // With A in bit 1: 11 -> 01 -> 00 -> 10 -> 11 is positive.
    accumulator_ += ((previous_ & 1) ^ (ab >> 1)) ? 1 : -1;
    previous_ = ab;
    if (accumulator_ >= edges_) { accumulator_ = 0; return 1; }
    if (accumulator_ <= -static_cast<int8_t>(edges_)) {
      accumulator_ = 0;
      return -1;
    }
    return 0;
  }
  uint32_t invalid() const { return invalid_; }
 private:
  uint8_t previous_ = 3;
  uint8_t edges_ = 4;
  int8_t accumulator_ = 0;
  uint32_t invalid_ = 0;
};

class Button {
 public:
  void begin(bool pressed, uint32_t now);
  bool update(bool pressed, uint32_t now);
 private:
  bool raw_ = false;
  bool stable_ = false;
  uint32_t changedAt_ = 0;
};

class Comet {
 public:
  void reset(uint16_t position = 0, uint8_t color = 0);
  void move(int8_t direction);
  void nextColor() { color_ = (color_ + 1) % kPaletteCount; }
  void setColor(uint8_t color) { if (color < kPaletteCount) color_ = color; }
  void render(Rgb* pixels) const;
  uint8_t color() const { return color_; }
  uint16_t logicalPosition() const { return history_[0]; }
  uint16_t pixel() const { return toPixel(history_[0]); }
 private:
  // PCB1.pcbdoc: the 40 DI/DO-connected LEDs run CCW in the top view.
  // Positive logical motion is CW, so the data-chain index must decrease.
  static uint16_t toPixel(uint16_t position) {
    return (rgbshow::kLedCount - position) % rgbshow::kLedCount;
  }
  uint16_t history_[kTrailLength] = {};
  uint8_t historyLength_ = 1;
  uint8_t color_ = 0;
};

class KnobScene {
 public:
  void reset();
  void select(uint8_t knob) { if (knob < kKnobCount) selected_ = knob; }
  void setIndependent(bool value) { independent_ = value; }
  bool independent() const { return independent_; }
  uint8_t selected() const { return selected_; }
  void move(uint8_t knob, int8_t direction);
  void nextColor(uint8_t knob);
  void setColor(uint8_t knob, uint8_t color);
  uint16_t pixel(uint8_t knob) const;
  uint8_t color(uint8_t knob) const;
  void render(Rgb* pixels) const;
 private:
  Comet& cursor(uint8_t knob) { return independent_ ? cursors_[knob] : shared_; }
  const Comet& cursor(uint8_t knob) const { return independent_ ? cursors_[knob] : shared_; }
  Comet cursors_[kKnobCount];
  Comet shared_;
  uint8_t selected_ = 3;
  bool independent_ = true;
};
}  // namespace stepcontrol
