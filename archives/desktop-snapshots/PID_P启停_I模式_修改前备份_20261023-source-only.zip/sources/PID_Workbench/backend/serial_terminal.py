"""Independent H1 receive-only UART, sharing the hardware gate with flash/PID."""
import secrets
import time
import datetime


class SerialTerminal:
    def __init__(self, gate, link_factory, resolve_port, error):
        self.gate, self.link_factory, self.resolve_port, self.error = gate, link_factory, resolve_port, error
        self.session = None
        self.config = None
        self.closed = True
        self.last_error = None
        self.last_read_at = None
        self.received_bytes = 0
        self.cache_cursor = None
        self.cached_read = None

    def status(self):
        return dict(session=self.session, config=self.config, closed=self.closed,
                    last_error=self.last_error, last_read_at=self.last_read_at, received_bytes=self.received_bytes)

    def validate(self, value):
        if not isinstance(value, dict) or set(value) - {"session", "port", "baud", "bits", "parity", "stop"}:
            raise self.error("invalid_serial_config", "串口配置字段无效。")
        config = dict(baud=value.get("baud", 115200), bits=value.get("bits", 8),
                      parity=value.get("parity", "N"), stop=value.get("stop", 1))
        for key, low, high in (("baud", 1200, 921600), ("bits", 5, 8), ("stop", 1, 2)):
            number = config[key]
            if type(number) is not int or not low <= number <= high:
                raise self.error("invalid_serial_config", f"{key} 范围为 {low}～{high}。")
        if config["parity"] not in ("N", "O", "E"):
            raise self.error("invalid_serial_config", "校验位必须为 N、O 或 E。")
        config["port"] = self.resolve_port(value.get("port", "auto"))
        session = value["session"] if "session" in value else secrets.token_hex(4)
        if not isinstance(session, str) or len(session) != 8 or any(c not in "0123456789abcdef" for c in session) or int(session, 16) == 0:
            raise self.error("invalid_serial_session", "session 必须为非零的 8 位小写十六进制数。")
        return session, config

    def acquire(self):
        if not self.gate.acquire(False):
            raise self.error("device_busy", "烧录或其他硬件操作进行中，日志轮询暂缓。", 409)

    def query(self, link, command, session, op, cursor=None):
        def accepts(reply):
            if reply.get("id") != int(session, 16) or reply.get("op") != op:
                return False
            return cursor is None or not reply.get("ok") or ((reply.get("offset", 0)-cursor) & 0xffffffff) < 0x80000000
        # Read/config/close are idempotent at a fixed session/cursor. The slave
        # retains bytes until acknowledged; no destructive retry is involved.
        value = link.query(command, "serial_log", accepts, timeout=5)
        if not value.get("ok"):
            failure = self.error("serial_remote_error", "从机日志接口：" + str(value.get("error")), 503)
            failure.remote_error = value.get("error")
            raise failure
        return value

    def configure(self, value):
        session, config = self.validate(value)
        self.acquire()
        link = None
        try:
            if session == self.session and config != self.config:
                raise self.error("serial_session_conflict", "修改配置请开始一个新日志会话。", 409)
            link = self.link_factory(None if config["port"] == "auto" else config["port"])
            parity = {"N": 0, "O": 1, "E": 2}[config["parity"]]
            result = self.query(link, f"!log open {session} {config['baud']} {config['bits']} {parity} {config['stop']}", session, 17)
            if session != self.session or self.closed:
                self.cache_cursor = self.cached_read = None
                self.received_bytes = 0
            self.session, self.config = session, config
            self.closed = False
            self.last_error = None
            return dict(session=session, config=config, cursor=0, rx_pin=44, tx_enabled=False,
                        buffer_bytes=32768, slave="44:1B:F6:8D:10:18", status=result)
        finally:
            if link is not None:
                link.close()
            self.gate.release()

    def check(self, session):
        if session != self.session or self.config is None:
            raise self.error("serial_session_expired", "日志会话已改变或服务已重启，请重新开始接收。", 409)

    def read(self, session, cursor):
        if type(cursor) is not int or not 0 <= cursor <= 0xffffffff:
            raise self.error("invalid_serial_cursor", "cursor 必须是 0～4294967295。")
        self.acquire()
        link = None
        try:
            self.check(session)
            if self.closed:
                raise self.error("serial_closed", "日志接收已被关闭。", 409)
            if self.cached_read is not None:
                if cursor == self.cache_cursor:
                    return self.cached_read
                if cursor != self.cached_read["next_cursor"]:
                    raise self.error("serial_cursor_conflict", "读取游标不连续，请使用上次返回的 next_cursor。", 409)
                self.cache_cursor = self.cached_read = None
            link = self.link_factory(None if self.config["port"] == "auto" else self.config["port"])
            chunks = []
            requested = cursor
            end = time.monotonic() + .15
            dropped = errors = 0
            for _ in range(16):
                try:
                    value = self.query(link, f"!log read {session} {cursor}", session, 18, cursor)
                except Exception as error:
                    self.last_error = str(error)
                    if chunks:
                        break  # Deliver already-acknowledged bytes before reporting the next error.
                    raise
                raw = bytes.fromhex(value["hex"])
                if len(raw) > 108:
                    raise self.error("serial_protocol", "从机日志块超出协议长度。", 503)
                actual = value["offset"]
                gap = (actual-cursor) & 0xffffffff
                if raw or gap:
                    chunks.append(dict(offset=actual, gap=gap, hex=raw.hex()))
                    self.received_bytes += len(raw)
                cursor = (actual+len(raw)) & 0xffffffff
                dropped, errors = value["dropped"], value["rx_errors"]
                if len(raw) < 108 or time.monotonic() >= end:
                    break
            result = dict(session=session, next_cursor=cursor, chunks=chunks, dropped=dropped,
                          rx_errors=errors, slave="44:1B:F6:8D:10:18")
            self.last_read_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
            if chunks:
                # Batched radio reads acknowledge earlier blocks. Retain the
                # entire HTTP response until the PC advances its cursor too.
                self.cache_cursor, self.cached_read = requested, result
            return result
        finally:
            if link is not None:
                link.close()
            self.gate.release()

    def close(self, value):
        if not isinstance(value, dict) or set(value) != {"session"}:
            raise self.error("invalid_serial_session", "关闭接收需要 session。")
        self.acquire()
        link = None
        try:
            session = value["session"]
            self.check(session)
            link = self.link_factory(None if self.config["port"] == "auto" else self.config["port"])
            self.query(link, f"!log close {session}", session, 19)
            self.closed = True
            # Retain the session so a lost close reply can safely be retried.
            return dict(session=session, closed=True)
        finally:
            if link is not None:
                link.close()
            self.gate.release()
