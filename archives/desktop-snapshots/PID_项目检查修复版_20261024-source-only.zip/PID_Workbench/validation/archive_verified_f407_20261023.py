"""Archive the verified sources, binaries and evidence; no hardware operations."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
import zipfile

OUTPUTS=Path(__file__).resolve().parents[2]
WORKBENCH=OUTPUTS/"PID_Workbench"
EVIDENCE=WORKBENCH/"validation/verify_replacement_f407_20261023"
STM32=Path(r"C:\Users\twice\Desktop\STM32PRO\f407")
ARCHIVE=Path(sys.argv[1]) if len(sys.argv)>1 else Path(r"C:\Users\twice\Desktop\PID_无线烧录已验证_20261023_1838.zip")
prepare=json.loads((EVIDENCE/"prepare.json").read_text(encoding="utf-8"))
flash=json.loads((EVIDENCE/"flash.json").read_text(encoding="utf-8"))
job=flash["job"]
assert prepare["ok"] and flash["ok"] and job["state"]=="succeeded"
assert job["result"]["verified"] and job["result"]["start_ack"]
job_dir=Path(flash["job_path"]).parent
slave=OUTPUTS/"ESP32_S3_Slave_Diagnostic/.pio/build/slave_flash_psram"
upload=json.loads((slave/"usb_upload.json").read_text(encoding="utf-8"))
assert upload["ok"] and upload["write_and_hash_verified"]
assert not ARCHIVE.exists(),"Refusing to overwrite an existing archive"

files={}
skip={".git",".pio","__pycache__","node_modules","validation","bin","obj"}
def tree(root,prefix,stm32=False):
    for path in root.rglob("*"):
        if not path.is_file():continue
        relative=path.relative_to(root)
        if any(part in skip for part in relative.parts):continue
        if path.suffix.lower() in {".pyc",".bak",".log",".o",".obj",".crf",".d",".dep",".lst"}:continue
        if stm32 and (relative.parts[0] in {"flash_records","bridge_backup_20261019","pid_bridge_backup_20261019"}
                      or relative.parts[:2]==("MDK-ARM","f407")):continue
        files[(Path(prefix)/relative).as_posix()]=path

for name in ("ESP32_S3_RGB_Chase","ESP32_S3_Slave_Diagnostic","PID_Shared"):
    tree(OUTPUTS/name,"sources/"+name)
tree(WORKBENCH/"backend","sources/PID_Workbench/backend")
tree(WORKBENCH/"integrations/keil","sources/PID_Workbench/integrations/keil")
tree(WORKBENCH/"docs","sources/PID_Workbench/docs")
tree(STM32,"sources/STM32_f407",stm32=True)
for path in WORKBENCH.iterdir():
    if path.is_file() and path.suffix.lower() in {".py",".cs",".cmd",".ps1",".txt",".json",".md"}:
        files["sources/PID_Workbench/"+path.name]=path
for name in ("build.log","prepare.json","flash.json","flash.log"):
    files["evidence/"+name]=EVIDENCE/name
for path in job_dir.iterdir():
    if path.is_file():files["evidence/keil/"+path.name]=path
for name in ("firmware.bin","bootloader.bin","partitions.bin","usb_upload.json"):
    files["binaries/slave_flash_psram/"+name]=slave/name
boot_app=Path(r"C:\Users\twice\.platformio\packages\framework-arduinoespressif32\tools\partitions\boot_app0.bin")
files["binaries/slave_flash_psram/boot_app0.bin"]=boot_app
files["binaries/host_flash/firmware.bin"]=OUTPUTS/"ESP32_S3_RGB_Chase/.pio/build/host_flash/firmware.bin"
files["binaries/STM32F407VET6/firmware.bin"]=job_dir/"firmware.bin"
files["binaries/STM32F407VET6/firmware.axf"]=job_dir/"source.axf"

def digest(data):return hashlib.sha256(data).hexdigest()
assert digest((job_dir/"firmware.bin").read_bytes())==job["result"]["sha256"]
app_record=next(i for i in upload["images"] if i["address"]==65536)
assert digest((slave/"firmware.bin").read_bytes())==app_record["sha256"]
manifest={"created_at":datetime.now().astimezone().isoformat(),"job_id":job["id"],
          "target":prepare["target"],"target_image_sha256":job["result"]["sha256"],
          "target_verified":True,"target_start_ack":True,"slave_upload_record":upload,
          "host_binary_provenance":"Local host_flash build artifact; not an independent readback of host Flash",
          "keil_download_configuration":"ST-Link wired; this wireless test used the adapter directly",
          "files":[]}
readme="""# 无线烧录已验证版本 — 2026-10-23 18:38

新 F407VET6，512 KiB、RDP=AA。原工程 8880 字节通过主机 USB → ESP-NOW → 从机 SWD 写入、完整读回、启动确认，任务 ccceb936d25638e73bdc59c1，重试 0 次，任务约12.44秒。

sources/ 保留本次验收时的主从固件、共享库、电脑后台/Keil 适配器和 STM32 工程源码；binaries/ 保留目标镜像、从机镜像及其上次 USB 写入校验记录，并附主机本地编译产物；evidence/ 保留本次完整任务证据。MANIFEST.json 列出每个文件的 SHA256。

从机使用 slave_flash_psram、16MB Flash/8MB Octal PSRAM；主机使用 host_flash。sources 下的 ESP32 工程和 PID_Shared 必须保持同级目录。ESP 固件的 bootloader/partitions/boot_app0/app 地址分别为 0x0/0x8000/0xE000/0x10000；这些地址只适用于该 ESP32 配置，不是 STM32 地址。目标 STM32 镜像地址为0x08000000，不能互相混烧。

本次没有刷写两块 ESP32，也没有解除新目标读保护。从机 BIN 的哈希与最近一次成功 USB 写入记录一致；主机 BIN 是磁盘本地编译产物，未独立读取主机 Flash，不将它冒充实板 Flash 备份。

Keil 工程当前保留 ST-Link 有线 Download 配置；本次无线验收直接调用 pid_keil.py。不要将恢复 Keil 项目配置与恢复 ESP 固件混为一项操作。恢复前先保存当前源码和配置，按硬件型号、USB序列号确认身份；不要自动解除读保护或重复擦除。

旧 F407 的 RDP=FF 异常没有在新目标复现，旧目标具体原因尚未独立确认。本包用于保存已验证版本，不承诺任意其他硬件可直接套用。
"""
with zipfile.ZipFile(ARCHIVE,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    bundle.writestr("README.md",readme)
    for name,path in sorted(files.items()):
        data=path.read_bytes();bundle.writestr(name,data)
        manifest["files"].append({"path":name,"bytes":len(data),"sha256":digest(data)})
    bundle.writestr("MANIFEST.json",json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(ARCHIVE) as bundle:
    assert bundle.testzip() is None,"ZIP CRC verification failed"
    for item in manifest["files"]:
        assert digest(bundle.read(item["path"]))==item["sha256"],item["path"]
acceptance={"state":"succeeded","job_id":job["id"],"verified":True,"start_ack":True,
            "bytes":job["result"]["size"],"retries":job["result"]["retries"],
            "seconds":(datetime.fromisoformat(job["completed_at"])-datetime.fromisoformat(job["started_at"])).total_seconds(),
            "target":prepare["target"],"target_image_sha256":job["result"]["sha256"],
            "backup_archive":str(ARCHIVE),"backup_sha256":digest(ARCHIVE.read_bytes()),
            "backup_files":len(files),"backup_integrity_verified":True,
            "keil_project_unchanged":True,"new_target_rdp_recovery_performed":False}
(EVIDENCE/("before_drive_modes_backup.json" if len(sys.argv)>1 else "acceptance.json")).write_text(json.dumps(acceptance,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(acceptance,ensure_ascii=False,indent=2))
