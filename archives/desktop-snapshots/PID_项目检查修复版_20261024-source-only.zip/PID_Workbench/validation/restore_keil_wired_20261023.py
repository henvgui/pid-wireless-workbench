"""Restore only the original Keil download settings; never flash a target."""
from datetime import datetime
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

project=Path(r"C:\Users\twice\Desktop\STM32PRO\f407\MDK-ARM\f407.uvprojx")
reference=project.with_name("f407.uvprojx.before_pid_20261019_183406_833360.bak")
original=project.read_bytes()
current=original.decode("utf-8-sig")
prior=reference.read_bytes().decode("utf-8-sig")
old_root=ET.fromstring(current)
assert old_root.findtext("./Targets/Target/TargetName")=="f407"
settings=re.search(r"<Utilities>.*?</Utilities>",prior,re.S).group()
assert ET.fromstring(settings).findtext("Flash1/UseTargetDll")=="1"
assert ET.fromstring(settings).findtext("Flash1/UseExternalTool")=="0"
assert ET.fromstring(settings).findtext("bUseTDR")=="1"
assert len(old_root.findall("./Targets/Target"))==1
updated,count=re.subn(r"<Utilities>.*?</Utilities>",lambda _:settings,current,flags=re.S)
assert count==1
new_root=ET.fromstring(updated)
assert "PidKeilDownload" not in updated and "pid_keil.py" not in updated
for root in (old_root,new_root):
    options=root.find("./Targets/Target/TargetOption")
    options.remove(options.find("Utilities"))
assert ET.tostring(old_root)==ET.tostring(new_root),"Unexpected change outside download settings"
options_file=project.with_suffix(".uvoptx")
option_root=ET.fromstring(options_file.read_bytes())
debug=option_root.find("./Target/TargetOption/DebugOpt")
assert debug.findtext("uTrg")=="1" and debug.findtext("pMon")==r"STLink\ST-LINKIII-KEIL_SWO.dll"
assert Path(r"C:\Keil_v5\ARM\STLink\ST-LINKIII-KEIL_SWO.dll").is_file()
stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
backup=project.with_name(project.name+".wireless_before_wired_"+stamp+".bak")
backup.write_bytes(original)
assert project.read_bytes()==original,"Concurrent Keil save; no edit applied"
project.write_bytes(updated.encode("utf-8"))
assert not project.read_bytes().startswith(b"\xef\xbb\xbf")
assert ET.fromstring(project.read_bytes()).findtext("./Targets/Target/TargetOption/Utilities/bUseTDR")=="1"
record=dict(project=str(project),backup=str(backup),reference=str(reference),
            debugger="ST-Link",interface="SWD",flash_algorithm="STM32F4xx_512.FLM",
            only_utilities_changed=True,target_flashed=False)
output=Path(__file__).with_suffix(".json")
output.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(record,ensure_ascii=False,indent=2))
