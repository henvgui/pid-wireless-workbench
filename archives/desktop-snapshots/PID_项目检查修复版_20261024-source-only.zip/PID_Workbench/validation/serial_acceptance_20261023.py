"""One-time local acceptance helper, without copying or printing API credentials."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).with_suffix("")
OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/"backend"))
import api_client

mode=sys.argv[1]
result={"mode":mode}
def save():
    (OUT/(mode+".json")).write_text(json.dumps(result,indent=2),encoding="utf-8")
try:
    jobs=api_client.request("/v1/jobs",start=False)["data"]
    result["active_jobs"]=[j["id"] for j in jobs if j["state"] in ("queued","running")]
    assert not result["active_jobs"],"Hardware job active"
    result["device"]=api_client.request("/v1/device",start=False)["data"]
    assert not result["device"].get("busy"),"Hardware busy"
    result["health"]=api_client.health()
    if mode=="restart":
        save()
        os.kill(result["health"]["pid"],signal.SIGTERM)
        time.sleep(.3)
        from workbench_core import DATA_DIR
        with (DATA_DIR/"server.log").open("ab") as log:
            child=subprocess.Popen([sys.executable,str(ROOT/"backend/server.py")],stdin=subprocess.DEVNULL,
                stdout=log,stderr=log,close_fds=True,creationflags=subprocess.CREATE_NO_WINDOW)
        for _ in range(30):
            time.sleep(.15)
            health=api_client.health()
            if health and health["version"]=="2026.10.23.1":break
        assert health and health["version"]=="2026.10.23.1","New service unavailable"
        result["new_health"]=health
    elif mode in ("flash_test","flash_retry"):
        test=ROOT/"validation/serial_f407_test_20261023"
        args=[sys.executable,"-u",str(ROOT/"integrations/keil/pid_keil.py"),
            "--firmware",str(test/"MDK-ARM/f407/f407.axf"),
            "--project",r"C:\Users\twice\Desktop\STM32PRO\f407\MDK-ARM\f407.uvprojx",
            "--chip","STM32F407VET6","--interface","swd",
            "--fromelf",r"C:\Keil_v5\ARM\ARMCC\bin\fromelf.exe",
            "--records-dir",r"C:\Users\twice\Desktop\STM32PRO\f407\flash_records\serial_test_20261023"]
        result["args"]=args;save()
        with (OUT/(mode+".log")).open("w",encoding="utf-8") as log:
            code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,
                env=dict(os.environ,PYTHONIOENCODING="utf-8",PYTHONUTF8="1"),creationflags=subprocess.CREATE_NO_WINDOW).returncode
        result["exit_code"]=code
        assert code==0,"Flash failed; inspect recorded job instead of submitting another erase"
    elif mode in ("protocol","receive_after_flash"):
        session="".join(__import__("secrets").choice("123456789abcdef") for _ in range(8))
        result["session"]=session;save()
        config=dict(session=session,port="auto",baud=115200,bits=8,parity="N",stop=1)
        result["open"]=api_client.request("/v1/serial/configure",config)["data"]
        cursor=0;chunks=[]
        for _ in range(20):
            value=api_client.request(f"/v1/serial/read?session={session}&cursor={cursor}")["data"]
            chunks.extend(value["chunks"]);cursor=value["next_cursor"]
            result["last_read"]=value
            time.sleep(.1)
        result["chunks"]=chunks
        result["received_bytes"]=sum(len(bytes.fromhex(c["hex"])) for c in chunks)
        result["close"]=api_client.request("/v1/serial/close",{"session":session})["data"]
        result["after"]=api_client.request("/v1/device",start=False)["data"]
    result["ok"]=True
except Exception as error:
    result["ok"]=False;result["error"]=str(error)
finally:
    save()
