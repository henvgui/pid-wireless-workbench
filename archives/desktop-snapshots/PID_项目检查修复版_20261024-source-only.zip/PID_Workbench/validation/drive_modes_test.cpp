#include "drive_control.h"
#include "host_local_core.h"
#include "pid_link_core.h"
#include <cassert>
#include <cstdio>
#include <cstring>

static MotorCommand command(uint32_t seq=1,uint32_t request=0,bool run=false,uint32_t mode=0) {
  MotorCommand c={}; c.session=100;c.sequence=seq;c.request=request;c.run=run;c.mode=mode;
  c.p100=50;c.i100=20;c.target_l100=c.target_r100=10000;c.limit100=5000;return c;
}
int main() {
  hostlocal::Session host; host.begin({{50,20,0},1},true);
  assert(host.mode()==0 && !host.requestedRun());
  assert(host.requestRun(true) && host.requestedRun());
  assert(host.requestRun(false) && !host.requestedRun());
  host.requestRun(true); const auto old=host.runRequest();
  assert(host.setMode(1) && !host.requestedRun() && host.runRequest()!=old && !host.dirty());
  assert(!host.acknowledgeRun(old,true) && !host.setMode(2));
  host.setMode(0); assert(!host.requestedRun());
  hostlocal::Command parsed;
  assert(hostlocal::parse("mode s_curve",parsed)==hostlocal::Parsed::Ok && parsed.mode==1);
  assert(hostlocal::parse("mode straight",parsed)==hostlocal::Parsed::Ok && parsed.mode==0);
  assert(hostlocal::parse("mode 2",parsed)==hostlocal::Parsed::Invalid);

  pidlink::Engine master,slave; master.begin(pidlink::Role::Host,11);slave.begin(pidlink::Role::Slave,22);
  pidlink::Snapshot s;s.mode=1;s.request=1;
  master.setDesired(s);pidlink::Frame f,ack,decoded;uint8_t wireless[48];
  assert(slave.next(0,f) && master.receive(f,0) && master.next(0,f));
  pidlink::encode(f,wireless);assert(pidlink::decode(wireless,48,decoded) && decoded.data.mode==1);
  assert(slave.receive(decoded,0) && slave.mirror().mode==1 && slave.next(0,ack) && master.receive(ack,0));
  assert(master.synced(0));
  s.mode=0;master.setDesired(s);assert(!master.synced(1));
  assert(master.next(40,f) && slave.receive(f,40) && slave.next(40,ack) && master.receive(ack,40));
  assert(master.synced(40) && slave.mirror().mode==0);

  uint8_t bytes[MOTOR_STATUS_SIZE],out[MOTOR_STATUS_SIZE];MotorCommand c=command(1,0,false,1),copy;
  MotorProto_Encode(&c,1,MOTOR_COMMAND_SIZE,bytes);
  assert(MotorProto_DecodeCommand(bytes,MOTOR_COMMAND_SIZE,&copy) && copy.mode==1);
  for(unsigned bit=0;bit<MOTOR_COMMAND_SIZE*8;bit++) {
    bytes[bit/8]^=1<<(bit%8);assert(!MotorProto_DecodeCommand(bytes,MOTOR_COMMAND_SIZE,&copy));bytes[bit/8]^=1<<(bit%8);
  }
  bytes[2]=1;MotorProto_Put32(bytes+MOTOR_COMMAND_SIZE-4,MotorProto_Crc(bytes,MOTOR_COMMAND_SIZE-4));
  assert(!MotorProto_DecodeCommand(bytes,MOTOR_COMMAND_SIZE,&copy)); // Reject legacy firmware.
  MotorParser parser={};MotorProto_Encode(&c,1,MOTOR_COMMAND_SIZE,bytes);
  for(unsigned i=0;i<9;i++) MotorProto_Feed(&parser,bytes[i],out);
  MotorProto_Feed(&parser,0xFF,out); // A broken frame followed by a complete retransmission resynchronizes.
  size_t n=0;for(unsigned i=0;i<MOTOR_COMMAND_SIZE;i++) n=MotorProto_Feed(&parser,bytes[i],out);
  assert(n==MOTOR_COMMAND_SIZE && MotorProto_DecodeCommand(out,n,&copy));

  DriveControl d;Drive_Init(&d);
  c=command(1,1,true);assert(!Drive_Apply(&d,&c,0) && !d.status.running);
  c=command();assert(Drive_Apply(&d,&c,0));
  c=command(2,1,true);assert(Drive_Apply(&d,&c,10) && d.status.running);
  assert(!Drive_Apply(&d,&c,100)); // Replay does not renew watchdog.
  Drive_Tick(&d,10,1,-1,1,65535);assert(d.status.duty_l100<=5000);
  Drive_Tick(&d,520,0,0,1,65535);
  assert(!d.status.running && !d.status.duty_l100 && (d.status.fault&MOTOR_FAULT_LINK));
  c=command(3,1,true);assert(Drive_Apply(&d,&c,530) && !d.status.running);
  c=command(4,2,false);assert(Drive_Apply(&d,&c,540) && !d.status.fault);
  c=command(5,3,true);assert(Drive_Apply(&d,&c,550) && d.status.running);
  c=command(6,4,true,1);Drive_Apply(&d,&c,560);assert(!d.status.running); // Mode edits cannot auto-run.
  c=command(7,5,false,1);Drive_Apply(&d,&c,570);
  c=command(8,6,true,1);Drive_Apply(&d,&c,580);assert(d.status.running);
  c=command(9,5,true,1);assert(!Drive_Apply(&d,&c,590)); // Older request cannot resurrect RUN.

  Drive_Init(&d);c=command(1,0,false,1);Drive_Apply(&d,&c,0);
  c=command(2,1,true,1);Drive_Apply(&d,&c,0);
  bool left=false,right=false;
  for(uint32_t t=10;t<=6100;t+=10) {
    if(t%100==0) {++c.sequence;assert(Drive_Apply(&d,&c,t));}
    Drive_Tick(&d,t,18,-18,0,0);assert(d.status.running && !d.status.fault);
    if(t==1500) left=d.status.target_l100>d.status.target_r100;
    if(t==4500) right=d.status.target_l100<d.status.target_r100;
    assert(d.status.duty_l100<=5000 && d.status.duty_r100<=5000);
  }
  assert(left && right);
  MotorStatus status;Drive_Status(&d,6110,&status);MotorProto_Encode(&status,2,MOTOR_STATUS_SIZE,bytes);
  MotorStatus roundtrip;assert(MotorProto_DecodeStatus(bytes,MOTOR_STATUS_SIZE,&roundtrip) && roundtrip.mode==1);
  c.session=101;c.sequence=1;assert(!Drive_Apply(&d,&c,6120));
  c.run=0;assert(Drive_Apply(&d,&c,6120) && !d.status.running);
  c.session=100;c.sequence=1000;assert(!Drive_Apply(&d,&c,6130));

  Drive_Init(&d);c=command();Drive_Apply(&d,&c,0);c=command(2,1,true);Drive_Apply(&d,&c,0);
  for(uint32_t t=10;t<2500;t+=10) {
    if(t%100==0) {++c.sequence;Drive_Apply(&d,&c,t);}
    Drive_Tick(&d,t,0,0,0,0);
  }
  assert(!d.status.running && (d.status.fault&MOTOR_FAULT_STALL_L) && !d.status.duty_l100);
  puts("PASS: P toggle, I mode STOP, mode ACK, CRC/replay/legacy rejection, parser recovery, watchdog, S alternation, stall and duty limit");
}
