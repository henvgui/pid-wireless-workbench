"""Recover only the identified ESP32 slave and validate the existing download path."""
import hashlib
import contextlib
import json
import subprocess
import site
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).with_suffix("")
OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/"backend"))
import api_client
from workbench_core import ports

mode=sys.argv[1]
record={"mode":mode}
try:
    jobs=api_client.request("/v1/jobs",start=False)["data"]
    assert not any(j["state"] in ("running","queued") for j in jobs),"Hardware job active"
    record["before"]=api_client.request("/v1/device",start=False)["data"]
    assert not record["before"].get("busy"),"Hardware busy"
    record["ports"]=ports()
    slave=next((p["port"] for p in record["ports"] if p["role"]=="slave"),None)
    esptool_dir=Path.home()/".platformio/packages/tool-esptoolpy"
    if mode=="probe":
        sys.path.insert(0,str(esptool_dir))
        site.addsitedir(str(esptool_dir/"_contrib"))
        from esptool.targets.esp32s3 import ESP32S3ROM
        chip=ESP32S3ROM(slave,115200)
        try:
            chip.connect(mode="usb_reset",attempts=3)
            reads=[]
            for _ in range(8):
                value=":".join(f"{b:02x}" for b in chip.read_mac())
                assert value=="44:1b:f6:8d:10:18","Wrong ESP32 identity"
                reads.append(value);time.sleep(.5)
            record["rom_identity_reads"]=reads
        finally:chip._port.close()
    elif mode in ("download","download_manual"):
        firmware=OUT/"slave_restored.bin"
        record["sha256"]=hashlib.sha256(firmware.read_bytes()).hexdigest()
        args=["--chip","esp32s3","--port",slave,"--baud","115200",
              "--before","no_reset","--after","no_reset" if mode=="download_manual" else "hard_reset","--no-stub","write_flash",
              "--flash_mode","keep","--flash_size","16MB","0x10000",str(firmware)]
        record["args"]=args
        sys.path.insert(0,str(esptool_dir));site.addsitedir(str(esptool_dir/"_contrib"))
        import esptool
        from esptool.targets.esp32s3 import ESP32S3ROM
        with (OUT/"download.log").open("w",encoding="utf-8") as log:
            with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
                chip=ESP32S3ROM(slave,115200)
                try:
                    chip.connect(mode="no_reset" if mode=="download_manual" else "usb_reset",attempts=3)
                    assert ":".join(f"{b:02x}" for b in chip.read_mac())=="44:1b:f6:8d:10:18","Wrong ESP32 identity"
                    # Keep the same USB handle from ROM sync through the write.
                    esptool.main(args,esp=chip)
                    record["exit_code"]=0
                finally:chip._port.close()
        time.sleep(2)
    elif mode=="verify":
        state=record["before"].get("state") or {}
        assert state.get("link_online") and state.get("synced"),"Wireless slave is not online"
        firmware=Path(r"C:\Users\twice\Desktop\STM32PRO\f407\MDK-ARM\f407\f407.axf")
        record["source_sha256"]=hashlib.sha256(firmware.read_bytes()).hexdigest()
        args=[sys.executable,"-u",str(ROOT/"integrations/keil/pid_keil.py"),"--firmware",str(firmware),
              "--project",r"C:\Users\twice\Desktop\STM32PRO\f407\MDK-ARM\f407.uvprojx",
              "--chip","STM32F407VET6","--interface","swd","--fromelf",r"C:\Keil_v5\ARM\ARMCC\bin\fromelf.exe",
              "--records-dir",str(OUT/"keil")]
        record["verify_args"]=args
        with (OUT/"verify.log").open("w",encoding="utf-8") as log:
            record["exit_code"]=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
        assert record["exit_code"]==0,"Existing Keil download verification failed; see verify.log"
        assert hashlib.sha256(firmware.read_bytes()).hexdigest()==record["source_sha256"],"User AXF changed during verification"
    elif mode=="swd_status":
        import serial
        assert slave,"Slave USB not present"
        link=serial.Serial();link.port=slave;link.baudrate=115200;link.timeout=.15;link.write_timeout=2;link.dtr=True;link.rts=False
        link.open();record["diagnostics"]=[]
        try:
            link.reset_input_buffer()
            for command,kind in [("!swd","swd"),("!status","status")]:
                link.write((command+"\n").encode());deadline=time.monotonic()+3
                while time.monotonic()<deadline:
                    try:value=json.loads(link.readline())
                    except ValueError:continue
                    if value.get("type")==kind:
                        record["diagnostics"].append(value);break
        finally:link.close()
    elif mode!="status":raise ValueError(mode)
    record["after"]=api_client.request("/v1/device",start=False)["data"]
    record["ok"]=True
except Exception as error:
    record.update(ok=False,error=str(error))
(OUT/(mode+".json")).write_text(json.dumps(record,indent=2),encoding="utf-8")
