"""Native acceptance for the F407 SWD capacity read; preserves user source and parameters."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).with_suffix("");OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/"backend"))
import api_client
from workbench_core import ports

mode=sys.argv[1];record={"mode":mode}
try:
    jobs=api_client.request("/v1/jobs",start=False)["data"]
    assert not any(j["state"] in ("running","queued") for j in jobs),"Existing hardware job active"
    record["before"]=api_client.request("/v1/device",start=False)["data"]
    assert not record["before"].get("busy"),"Hardware busy"
    record["ports"]=ports()
    if mode=="upload":
        args=[str(Path(sys.executable).with_name("platformio.exe")),"run","-d",str(ROOT.parent/"ESP32_S3_Slave_Diagnostic"),"-t","upload"]
        with (OUT/"upload.log").open("w",encoding="utf-8") as log:
            record["exit_code"]=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
        assert record["exit_code"]==0,"Slave automatic update failed; see upload.log"
    elif mode=="flash":
        state=record["before"].get("state") or {}
        assert state.get("link_online") and state.get("synced"),"Wireless slave not online"
        firmware=Path(r"C:\Users\twice\Desktop\STM32PRO\f407\MDK-ARM\f407\f407.axf")
        record["axf_sha256"]=hashlib.sha256(firmware.read_bytes()).hexdigest()
        args=[sys.executable,"-u",str(ROOT/"integrations/keil/pid_keil.py"),"--firmware",str(firmware),
              "--project",r"C:\Users\twice\Desktop\STM32PRO\f407\MDK-ARM\f407.uvprojx", "--chip","STM32F407VET6",
              "--interface","swd","--fromelf",r"C:\Keil_v5\ARM\ARMCC\bin\fromelf.exe","--records-dir",str(OUT/"keil")]
        with (OUT/"flash.log").open("w",encoding="utf-8") as log:
            record["exit_code"]=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
        assert record["exit_code"]==0,"Keil adapter flash failed; see latest job result"
        assert hashlib.sha256(firmware.read_bytes()).hexdigest()==record["axf_sha256"],"AXF changed during verification"
    elif mode in ("diagnose","probe","recover"):
        if mode=="recover":
            assert "--confirm-erase-all-f407ve" in sys.argv,"Full Flash erase requires explicit human approval"
            assert record["before"].get("state",{}).get("run_request") is False,"Stop required before recovery"
            record["operation"]="RDP ff->aa; erase entire F407VE user Flash; no application start"
        import serial
        slave=next(p["port"] for p in record["ports"] if p["role"]=="slave")
        link=serial.Serial();link.port=slave;link.baudrate=115200;link.timeout=.15;link.write_timeout=2;link.dtr=True;link.rts=False;link.open()
        record["diagnostics"]=[]
        try:
            link.reset_input_buffer()
            commands=([("!swdprobe","swdprobe")] if mode=="probe" else
                      [("!swdunprotect ERASE_ALL_F407VE","swdrecovery")] if mode=="recover" else
                      [("!swd","swd"),("!info","info")])
            for command,kind in commands:
                link.write((command+"\n").encode());until=time.monotonic()+3
                while time.monotonic()<until:
                    try:value=json.loads(link.readline())
                    except (ValueError,UnicodeError):continue
                    if value.get("type")==kind:record["diagnostics"].append(value);break
            assert len(record["diagnostics"])==len(commands),"Missing diagnostic response"
            if mode=="probe":assert record["diagnostics"][0]["error"]=="ok","SWD probe failed; see diagnostic values"
            if mode=="recover":
                assert record["diagnostics"][0].get("accepted"),"Recovery not accepted; command will not be replayed"
                until=time.monotonic()+75
                with (OUT/"recover.log").open("w",encoding="utf-8") as log:
                    while time.monotonic()<until:
                        link.write(b"!swd\n");response_end=time.monotonic()+2
                        while time.monotonic()<response_end:
                            try:value=json.loads(link.readline())
                            except (ValueError,UnicodeError):continue
                            if value.get("type")=="swd":break
                        else:raise TimeoutError("Recovery status unavailable; do not replay erase command")
                        log.write(json.dumps(value)+"\n");log.flush()
                        if value.get("recovery_state") in (2,3):
                            record["recovery_result"]=value
                            assert value["recovery_state"]==2 and value["error"]=="ok","Recovery failed; do not replay erase command"
                            assert (value["option_bytes_after"]>>8)&255==0xaa,"RDP readback mismatch"
                            break
                        time.sleep(.25)
                    else:raise TimeoutError("Recovery timed out; do not replay erase command")
        finally:link.close()
    elif mode!="status":raise ValueError(mode)
    record["after"]=api_client.request("/v1/device",start=False)["data"]
    record["ok"]=True
except Exception as error:record.update(ok=False,error=str(error))
(OUT/(mode+".json")).write_text(json.dumps(record,indent=2),encoding="utf-8")
