"""Native Windows hardware actions. Never sends RUN or writes saved PID parameters."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import struct
import subprocess
import sys
import time
import zlib

ROOT=Path(__file__).resolve().parents[1]
OUTPUTS=ROOT.parent
OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=True)
sys.path[:0]=[str(ROOT/'backend'),str(OUTPUTS/'PID_Shared/PIDFlash/tools')]
import api_client
from workbench_core import ports
from flash_stm32 import Link

mode=sys.argv[1]
record={'mode':mode,'started_at':datetime.now(timezone.utc).isoformat()}
try:
    jobs=api_client.request('/v1/jobs',start=False)['data']
    assert not any(j['state'] in ('running','queued') for j in jobs),'Hardware job active'
    record['ports']=ports()
    record['serial_status']=api_client.request('/v1/serial/status',start=False)['data']
    if mode=='inspect':
        record['device']=api_client.request('/v1/device',start=False)['data']
    elif mode=='quiesce':
        status=record['serial_status']
        if status.get('session') and not status.get('closed',True):
            try:
                record['closed_log']=api_client.request('/v1/serial/close',{'session':status['session']},start=False)['data']
            except Exception as error:
                if 'wrong_transfer' not in str(error):raise
                record['stale_log_session']=True
                api_client.request('/v1/serial/configure',dict(status['config'],session=status['session']),start=False)
                record['closed_log']=api_client.request('/v1/serial/close',{'session':status['session']},start=False)['data']
    elif mode=='restore_log':
        baseline=json.loads((OUT/'inspect.json').read_text(encoding='utf-8'))['serial_status']
        if baseline.get('session') and not baseline.get('closed',True):
            record['restored']=api_client.request('/v1/serial/configure',dict(baseline['config'],session=baseline['session']),start=False)['data']
    elif mode=='diagnose':
        link=Link()
        try:
            record['state']=link.query('!get','state')
            record['motor']=[]
            for _ in range(3):
                ident=secrets.randbits(31) or 1
                record['motor'].append(link.query(f'!motor status {ident:x}','motor',lambda x:x.get('id')==ident))
                time.sleep(.2)
            ident=secrets.randbits(31) or 1
            record['raw_h2']=link.query(f'!uart read {ident:x} 300','uart',lambda x:x.get('id')==ident)
        finally:link.close()
    elif mode=='h1_log':
        ident=secrets.token_hex(4)
        record['opened']=api_client.request('/v1/serial/configure',{'session':ident,'port':'auto','baud':115200,'bits':8,'parity':'N','stop':1},start=False)['data']
        try:
            time.sleep(.4)
            record['read']=api_client.request(f'/v1/serial/read?session={ident}&cursor=0',start=False)['data']
        finally:record['closed']=api_client.request('/v1/serial/close',{'session':ident},start=False)['data']
    elif mode in ('upload_host','upload_slave'):
        if not record['serial_status'].get('closed',True):
            raise RuntimeError('Serial capture active; preserve it before firmware update')
        inspect=json.loads((OUT/'inspect.json').read_text(encoding='utf-8'))
        assert inspect['ok'] and not inspect['device'].get('busy')
        slave=mode=='upload_slave'
        project=OUTPUTS/('ESP32_S3_Slave_Diagnostic' if slave else 'ESP32_S3_RGB_Chase')
        args=[str(Path(sys.executable).with_name('platformio.exe')),'run','-e',
              'slave_flash_psram' if slave else 'host_flash','-t','upload']
        log=OUT/(mode+'.log')
        with log.open('w',encoding='utf-8') as f:
            proc=subprocess.run(args,cwd=project,stdout=f,stderr=subprocess.STDOUT,timeout=120)
        record['exit_code']=proc.returncode
        assert proc.returncode==0,'Upload failed; inspect '+str(log)
        record['firmware_sha256']=hashlib.sha256((project/'.pio/build'/('slave_flash_psram' if slave else 'host_flash')/'firmware.bin').read_bytes()).hexdigest()
        if slave:
            report=project/'.pio/build/slave_flash_psram/usb_upload.json'
            record['usb_report']=json.loads(report.read_text(encoding='utf-8'))
            assert record['usb_report']['ok'] and record['usb_report']['write_and_hash_verified']
            assert record['usb_report']['application']['version']=='20261023.3'
    elif mode in ('host_state','verify_modes'):
        link=Link()
        try:
            record['before']=link.query('!get','state')
            assert not record['before']['run_request'],'Host RUN unexpectedly active; no automatic test'
            end=time.monotonic()+8
            while not record['before'].get('synced') and time.monotonic()<end:
                time.sleep(.2);record['before']=link.query('!get','state')
            assert record['before'].get('synced'),'Wireless not synchronized'
            baseline=json.loads((OUT/'inspect.json').read_text(encoding='utf-8'))['device']['state']
            assert all(record['before'][k]==baseline[k] for k in ('p','i','d','step','stream','saved','dirty')),'Host parameters changed'
            if mode=='verify_modes':
                record['tests']=[]
                record['responses']=[]
                names=('app','session','sequence','revision','request','tick_ms','running','fault',
                       'target_l100','target_r100','speed_l100','speed_r100','duty_l100','duty_r100',
                       'p100','i100','d100','encoder_l','encoder_r','command_age_ms','limit100')
                for name,expected in (('s_curve',1),('straight',0)):
                    state=link.query('!mode '+name,'state')
                    end=time.monotonic()+8
                    while True:
                        ident=secrets.randbits(31) or 1
                        response=link.query(f'!motor status {ident:x}','motor',lambda x:x.get('id')==ident)
                        record['responses'].append(response)
                        if response.get('ok'):
                            raw=bytes.fromhex(response['hex']);assert len(raw)==104
                            frame=raw[8:];assert frame[:4]==b'MP\x02\x02' and len(frame)==96
                            assert struct.unpack_from('<I',frame,92)[0]==zlib.crc32(frame[:92])
                            target=dict(zip(names,struct.unpack_from('<21I',frame,8)))
                            target['mode']=frame[6];target['age_ms'],target['inhibited']=struct.unpack_from('<II',raw)
                            if target['mode']==expected and target['request']==state['request_id']:
                                assert target['app']==0x3244504D and target['running']==0 and target['fault']==0
                                assert not target['duty_l100'] and not target['duty_r100'] and not target['inhibited']
                                record['tests'].append({'mode':name,'host':state,'target':target});break
                        if time.monotonic()>end:raise RuntimeError('No matching STM32 mode/STOP confirmation')
                        time.sleep(.15)
            record['after']=link.query('!get','state')
            assert not record['after']['run_request'] and record['after']['mode']=='straight'
        finally:
            if mode=='verify_modes':
                try:link.query('!mode straight','state');link.query('!stop','state')
                except Exception:pass
            link.close()
    else:raise ValueError(mode)
    record['ok']=True
except Exception as error:record.update(ok=False,error=str(error))
record['completed_at']=datetime.now(timezone.utc).isoformat()
(OUT/(mode+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
