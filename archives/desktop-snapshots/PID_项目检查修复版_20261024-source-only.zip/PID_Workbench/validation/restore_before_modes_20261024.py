"""Back up current mode-control version, then restore only its known source edits."""
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile
from pathlib import Path

OUT=Path(__file__).resolve().parents[2]
STM=Path(r'C:\Users\twice\Desktop\STM32PRO\f407')
BASE=Path(r'C:\Users\twice\Desktop\PID_P启停_I模式_修改前备份_20261023.zip')
BACKUP=Path(r'C:\Users\twice\Desktop\PID_P按键S弯版本_恢复前备份_20261024.zip')
RECORD=Path(__file__).with_suffix('');RECORD.mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(BASE.read_bytes())=='a70c15f0b4a60581df7fae96b7d44b861d7ca34a051eec2fedbc1bd9d6ee1400'
assert not BACKUP.exists(),'Refuse to overwrite an earlier backup'
skip={'.git','.pio','__pycache__','node_modules','validation','flash_records','bridge_backup_20261019','pid_bridge_backup_20261019'}
files={}
for root,name in [(OUT/x,x) for x in ('ESP32_S3_RGB_Chase','ESP32_S3_Slave_Diagnostic','PID_Shared')]+[(STM,'STM32_f407')]:
    for p in root.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if any(x in skip for x in rel.parts) or p.suffix.lower() in {'.o','.crf','.d','.dep','.lst','.log'}:continue
        if name=='STM32_f407' and rel.parts[:2]==('MDK-ARM','f407'):continue
        files['sources/'+name+'/'+rel.as_posix()]=p
for name,path in {
    'host.bin':OUT/'ESP32_S3_RGB_Chase/.pio/build/host_flash/firmware.bin',
    'slave.bin':OUT/'ESP32_S3_Slave_Diagnostic/.pio/build/slave_flash_psram/firmware.bin',
    'f407.axf':STM/'MDK-ARM/f407/f407.axf',
    'acceptance.json':OUT/'PID_Workbench/validation/drive_modes_hardware_20261023/acceptance.json',
}.items():files['binaries_or_evidence/'+name]=path
manifest={'created_at':datetime.now(timezone.utc).isoformat(),'purpose':'Restore the pre-P/I-button source version; preserve the mode-control version first','files':[]}
with zipfile.ZipFile(BACKUP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for name,p in sorted(files.items()):
        raw=p.read_bytes();bundle.writestr(name,raw)
        manifest['files'].append({'path':name,'sha256':sha(raw),'bytes':len(raw)})
    bundle.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(BACKUP) as bundle:
    assert bundle.testzip() is None
    for entry in manifest['files']:assert sha(bundle.read(entry['path']))==entry['sha256']

paths={
 'ESP32_S3_RGB_Chase':['include/host_local_core.h','src/host_local_core.cpp','include/host_local_app.h','src/host_local_app.cpp','src/knob_main.cpp'],
 'ESP32_S3_Slave_Diagnostic':['src/main.cpp'],
 'PID_Shared':['PIDLink/src/pid_link_core.h','PIDLink/src/pid_link_core.cpp','PIDFlash/src/motor_protocol.h','PIDFlash/src/motor_bridge.cpp'],
 'STM32_f407':['Core/Src/main.c','Core/Src/stm32f4xx_it.c','MDK-ARM/f407.uvprojx'],
}
restored=[]
with zipfile.ZipFile(BASE) as bundle:
    entries={x['path']:x for x in json.loads(bundle.read('MANIFEST.json'))['files']}
    for name,relative_paths in paths.items():
        root=STM if name=='STM32_f407' else OUT/name
        for rel in relative_paths:
            member='sources/'+name+'/'+rel;raw=bundle.read(member)
            assert sha(raw)==entries[member]['sha256']
            p=root/rel;p.write_bytes(raw)
            restored.append({'path':str(p),'sha256':sha(raw)})
    extra=['Core/Inc/drive_app.h','Core/Inc/drive_control.h','Core/Inc/motor_protocol.h','Core/Src/drive_app.c','Core/Src/drive_control.c','P_I按键与行驶模式使用说明.md']
    parked=[]
    for rel in extra:
        assert 'sources/STM32_f407/'+rel not in entries,'File belongs to baseline; do not park it'
        p=(STM/rel).resolve();assert p.is_relative_to(STM.resolve())
        if p.exists():
            dest=RECORD/'parked_mode_files'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
            assert not dest.exists();shutil.move(str(p),str(dest));parked.append(str(p))
record={'backup':str(BACKUP),'backup_sha256':sha(BACKUP.read_bytes()),'backup_integrity_verified':True,
        'baseline':str(BASE),'restored':restored,'parked':parked,'hardware_written':False}
(RECORD/'restore.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'backup':str(BACKUP),'restored_files':len(restored),'parked_files':len(parked)},ensure_ascii=False))
