import json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
app=root.parents[1]
sys.path.insert(0,str(app/'backend'))
sys.path.insert(0,str(app/'integrations'/'keil'))
import api_client
# Deliberately use a client data directory with no native token, like Keil's
# view outside Codex MSIX. Do not change the running server's directory.
api_client.DATA_DIR=root/'missing_native_data'
assert not (api_client.DATA_DIR/'api_token.txt').exists()
import pid_keil
try:
    caps=api_client.request('/v1/capabilities')
    assert caps['ok']
    result=pid_keil.execute_record(root/'existing_job_resume.json',timeout=10,resume=True)
    assert result==0
    (root/'keil_probe_result.json').write_text(json.dumps({'passed':True,'missing_native_token':True,'keil_external_tool':True,'existing_job_only':True,'flash_replayed':False}),encoding='utf-8')
except Exception as error:
    (root/'keil_probe_result.json').write_text(json.dumps({'passed':False,'error':str(error)}),encoding='utf-8')
    raise
