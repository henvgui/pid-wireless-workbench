import json, sys
from pathlib import Path
Path(__file__).with_suffix(".json").write_text(json.dumps(sys.argv),encoding="utf-8")
print("PID KEIL PROBE OK", repr(sys.argv),flush=True)
