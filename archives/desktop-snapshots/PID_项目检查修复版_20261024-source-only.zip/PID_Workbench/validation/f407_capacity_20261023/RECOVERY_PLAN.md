# F407VET6 读保护恢复方案与记录

2026-10-23。当前 ESP32 从机 USB 自动下载、应用启动和 ESP-NOW 重连正常；STM32 烧录尚未恢复。

## 实测依据

- SWD DPIDR：`0x2BA01477`；DBGMCU_IDCODE：`0x101F6413`。
- F407 断电重上电后，连续两次 `FLASH_OPTCR=0x0FFFFFED`，即 `RDP=0xFF`；访问出厂容量地址出现 SWD FAULT。
- 断电前 Flash、UID、容量地址均返回全 FF。仅按配置强行继续的试验没有通过读回校验，已撤回该兼容处理；正常烧录仍严格检查容量和保护状态。
- 不能仅凭这些结果确定读保护异常的起因，也不能将其当成芯片损坏的证明。

用户已明确同意“全片擦除并重烧当前工程”，授权记录为同目录 `recovery_approval.json`。已执行一次解除操作，`recover.json` 中选项寄存器即时读回 `0x0FFFAAED`，但随后的复位诊断仍读到 `0x0FFFFFED`；不能据此宣告解除成功或擦除已持久生效。目前等待三块板完全断电重上电后复核，不自动重放解除/擦除命令。

## 已获授权的操作

1. 通过从机 H3 的 SWD，仅将 RDP 从 `0xFF` 恢复为 `0xAA`，保留 BOR、看门狗和写保护配置。该操作将擦除 **STM32 的整片用户 Flash（当前 VET6 为 512 KiB）**，包括应用程序和其中保存的数据；旧数据无法读取备份。
2. 不修改 OTP、主机 NVS 或电脑上的工程文件。只恢复观察到的 `RDP=0xFF`，不尝试 RDP Level 2，不自动重放超时的擦除操作。
3. 解除后重新检查容量、UID 和 Flash 是否可读；必要时需目标板复位或断电重启。容量仍异常则停止，不绕过。
4. 通过原 Keil 适配器、主机 USB、ESP-NOW、从机 SWD，重新写入原工程，完整读回验证并确认启动。

## 待重写的原工程

- 工程：`C:/Users/twice/Desktop/STM32PRO/f407/MDK-ARM/f407.uvprojx`
- AXF：`C:/Users/twice/Desktop/STM32PRO/f407/MDK-ARM/f407/f407.axf`
- AXF SHA256：`e02d1b39ca72e7119803374496f60efc9482875c35e59c9e34c1c3cad023d5bc`
- BIN：8880 字节；SHA256：`1796653585af5ce29e3ad0b0e31332ba286ec4065fca4081d602552e925dd9a4`
- 不改 STM32 源码。当前用户应用可能产生 PWM；主机 STOP 不能代替目标应用的停机确认。

## 工具与门槛

恢复入口是从机 USB 的显式命令 `!swdunprotect ERASE_ALL_F407VE`。普通烧录、上电、连接和诊断均不调用它。主机任务空闲、STOP、设备 ID 正确、两次 RDP 读取相同，才允许开始。一次恢复后拒绝重复触发。

Native helper 位于本目录上级的 `f407_capacity_20261023.py`，`recover` 模式还必须带 `--confirm-erase-all-f407ve`；未获得用户同意前不执行该模式。**本轮已执行一次，不因读取失败而重放。** 解除操作本身不启动应用；必须由后续完整烧录校验决定是否启动。

成功标准：最终 Keil 任务 `state=succeeded`、`result.verified=true`、`result.start_ack=true`。当前尚不满足。

协议依据：[ST 的 RDP 说明](https://www.st.com/content/st_com/en/technical-documents/an5156-introduction-to-security-for-stm32-mcus-stmicroelectronics_asset/chunk-006-topic-an5156-sec-feat-read-out-protection-rdp-.html)、[OpenOCD F2/F4 选项字节实现](https://github.com/openocd-org/openocd/blob/master/src/flash/nor/stm32f2x.c)。
