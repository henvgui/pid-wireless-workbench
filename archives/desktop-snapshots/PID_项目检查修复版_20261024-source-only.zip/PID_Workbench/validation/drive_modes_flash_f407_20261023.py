"""Verify a replacement F407 using existing ESP-NOW/SWD; no RDP recovery."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).with_suffix("");OUT.mkdir(exist_ok=True)
PROJECT=Path(r"C:\Users\twice\Desktop\STM32PRO\f407\MDK-ARM\f407.uvprojx")
AXF=PROJECT.parent/"f407/f407.axf"
sys.path.insert(0,str(ROOT/"backend"))
import api_client
from workbench_core import ports

mode=sys.argv[1]
record={"mode":mode,"started_at":datetime.now(timezone.utc).isoformat()}
try:
    jobs=api_client.request("/v1/jobs",start=False)["data"]
    assert not any(j["state"] in ("running","queued") for j in jobs),"Hardware job active"
    record["before"]=api_client.request("/v1/device",start=False)["data"]
    assert not record["before"].get("busy"),"Hardware busy"
    record["ports"]=ports()
    record["keil_project_sha256"]=hashlib.sha256(PROJECT.read_bytes()).hexdigest()
    if mode=="prepare":
        build_log=OUT/"build.log"
        startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW;startup.wShowWindow=0
        args=[r"C:\Keil_v5\UV4\UV4.exe","-b",str(PROJECT),"-t","f407","-o",str(build_log)]
        result=subprocess.run(args,cwd=PROJECT.parent,startupinfo=startup,timeout=120)
        record["build_exit_code"]=result.returncode
        assert result.returncode in (0,1),"Keil build failed; see build.log"
        record["axf_sha256"]=hashlib.sha256(AXF.read_bytes()).hexdigest()
        import serial
        slave=next(p["port"] for p in record["ports"] if p["role"]=="slave")
        link=serial.Serial();link.port=slave;link.baudrate=115200;link.timeout=.15;link.write_timeout=2;link.dtr=True;link.rts=False;link.open()
        try:
            link.reset_input_buffer();link.write(b"!swdprobe\n");until=time.monotonic()+5
            while time.monotonic()<until:
                try:value=json.loads(link.readline())
                except (ValueError,UnicodeError):continue
                if value.get("type")=="swdprobe":record["probe"]=value;break
            assert "probe" in record,"No SWD probe response"
        finally:link.close()
        probe=record["probe"];assert probe["error"]=="ok","Target probe failed; no erase permitted"
        values=probe["after_reset"]
        record["target"]={"idcode":values[0],"device_id":values[0]&4095,"flash_kb":values[6]>>16,
                          "rdp":(values[5]>>8)&255,"uid_word0":values[10]}
        assert record["target"]["device_id"]==0x413,"Wrong device family"
        assert record["target"]["flash_kb"]==512,"Target capacity differs from VET6 project"
        assert record["target"]["rdp"]==0xaa,"Target protected; no unlock attempted"
    elif mode=="flash":
        preparation=json.loads((OUT/"prepare.json").read_text(encoding="utf-8"))
        assert preparation["ok"],"Preparation did not pass"
        record["axf_sha256"]=hashlib.sha256(AXF.read_bytes()).hexdigest()
        assert record["axf_sha256"]==preparation["axf_sha256"],"AXF changed since preparation"
        state=record["before"].get("state") or {}
        assert state.get("link_online") and state.get("synced"),"Wireless slave not online"
        args=[sys.executable,"-u",str(ROOT/"integrations/keil/pid_keil.py"),"--firmware",str(AXF),
              "--project",str(PROJECT),"--chip","STM32F407VET6","--interface","swd",
              "--fromelf",r"C:\Keil_v5\ARM\ARMCC\bin\fromelf.exe","--records-dir",str(OUT/"keil")]
        with (OUT/"flash.log").open("w",encoding="utf-8") as log:
            result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
        record["exit_code"]=result.returncode
        job_path=max((OUT/"keil").glob("*/job.json"),key=lambda p:p.stat().st_mtime)
        job=json.loads(job_path.read_text(encoding="utf-8"))
        record["job_path"]=str(job_path);record["job"]=job
        assert result.returncode==0 and job["state"]=="succeeded","Flash failed; inspect job, do not resubmit"
        assert job["result"].get("verified") and job["result"].get("start_ack"),"Missing readback/start confirmation"
        assert hashlib.sha256(AXF.read_bytes()).hexdigest()==record["axf_sha256"],"AXF changed during flash"
    elif mode!="status":raise ValueError(mode)
    assert hashlib.sha256(PROJECT.read_bytes()).hexdigest()==record["keil_project_sha256"],"Keil configuration changed"
    record["after"]=api_client.request("/v1/device",start=False)["data"]
    record["ok"]=True
except Exception as error:record.update(ok=False,error=str(error))
record["completed_at"]=datetime.now(timezone.utc).isoformat()
(OUT/(mode+".json")).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding="utf-8")
