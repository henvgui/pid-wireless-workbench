"""Package verified firmware, source and evidence. No device writes."""
from datetime import datetime,timezone
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];WB=ROOT/'PID_Workbench';STM=Path(r'C:\Users\twice\Desktop\STM32PRO\f407')
PROOF=WB/'validation/wireless_upgrade_20261024'
DEST=Path(r'C:\Users\twice\Desktop\PID_无线烧录提速版_20261024.zip')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
base,opt,keil=[read(PROOF/(name+'.json')) for name in ('baseline_flash','optimized_flash','keil_flash')]
assert all(x['ok'] and x['job']['state']=='succeeded' and x['job']['result']['verified'] and not x['job']['spec']['run'] for x in (base,opt,keil))
image_sha='1796653585af5ce29e3ad0b0e31332ba286ec4065fca4081d602552e925dd9a4'
assert all(x['job']['result']['sha256']==image_sha for x in (base,opt,keil))
assert opt['job']['result']['chunk_bytes']==keil['job']['result']['chunk_bytes']==192
state=read(PROOF/'state.json');assert state['ok']
assert sha((WB/'backend/protocol/flash_stm32.py').read_bytes())==sha((ROOT/'PID_Shared/PIDFlash/tools/flash_stm32.py').read_bytes())
project=(STM/'MDK-ARM/f407.uvprojx').read_bytes()
assert not project.startswith(b'\xef\xbb\xbf') and b'<UseExternalTool>1</UseExternalTool>' in project
assert b'PidKeilDownload.exe' in project
host,slave=[read(PROOF/(name+'.json')) for name in ('upload_host','upload_slave')]
assert host['ok'] and slave['ok'] and slave['usb']['write_and_hash_verified']
for name,env,record in [('ESP32_S3_RGB_Chase','host_flash',host),('ESP32_S3_Slave_Diagnostic','slave_flash_psram',slave)]:
    assert sha((ROOT/name/'.pio/build'/env/'firmware.bin').read_bytes())==record['sha256']
acceptance={'completed_at':datetime.now(timezone.utc).isoformat(),'restore_source':'PID_P启停_I模式_修改前备份_20261023.zip',
 'mode_version_backup':'PID_P按键S弯版本_恢复前备份_20261024.zip','bytes':8880,'image_sha256':image_sha,
 'baseline_seconds':base['seconds'],'optimized_seconds':opt['seconds'],'keil_seconds':keil['seconds'],
 'time_reduction_percent':round((1-keil['seconds']/base['seconds'])*100,2),
 'jobs':[x['job']['id'] for x in (base,opt,keil)],'full_readback_verified':True,'target_auto_start':False,
 'parameters':state['device']['state'],'keil_external_download_enabled':True,
 'offline_tests':{'flash_tool_python':10,'keil_python':15,'backend_python':22,'launcher_python':7,'native_flash_and_swd':'passed'},
 'backend_version':'2026.10.24.1','slave_version':'20261024.1','max_chunk_bytes':192,'swd_half_period_us':2}
(PROOF/'acceptance.json').write_text(json.dumps(acceptance,ensure_ascii=False,indent=2),encoding='utf-8')

files={};skip={'.git','.pio','__pycache__','node_modules','validation','flash_records','bridge_backup_20261019','pid_bridge_backup_20261019'}
for root,name in [(ROOT/x,x) for x in ('ESP32_S3_RGB_Chase','ESP32_S3_Slave_Diagnostic','PID_Shared','PID_Workbench')]+[(STM,'STM32_f407')]:
    for p in root.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if any(x in skip for x in rel.parts) or p.suffix.lower() in {'.pyc','.o','.crf','.d','.dep','.lst','.log','.bak'}:continue
        if name=='STM32_f407' and rel.parts[:2]==('MDK-ARM','f407'):continue
        files['sources/'+name+'/'+rel.as_posix()]=p
for root in (PROOF,WB/'validation/restore_before_modes_20261024'):
    for p in root.rglob('*'):
        if p.is_file() and 'before' not in p.relative_to(root).parts and 'parked_mode_files' not in p.relative_to(root).parts and p.suffix.lower() in ('.json','.log','.png'):
            files['evidence/'+root.name+'/'+p.relative_to(root).as_posix()]=p
for name,env in [('ESP32_S3_RGB_Chase','host_flash'),('ESP32_S3_Slave_Diagnostic','slave_flash_psram')]:
    for filename in ('firmware.bin','bootloader.bin','partitions.bin'):
        files['binaries/'+env+'/'+filename]=ROOT/name/'.pio/build'/env/filename
files['binaries/boot_app0.bin']=Path(r'C:\Users\twice\.platformio\packages\framework-arduinoespressif32\tools\partitions\boot_app0.bin')
files['binaries/STM32F407VET6.bin']=Path(keil['job_path']).parent/'firmware.bin'
files['binaries/STM32F407VET6.axf']=Path(keil['job_path']).parent/'source.axf'
files['README.md']=STM/'无线烧录提速与Keil接入_20261024.md'
manifest={'acceptance':acceptance,'host_bin_sha256':host['sha256'],'slave_bin_sha256':slave['sha256'],'files':[]}
assert not DEST.exists(),'Refuse to overwrite an archive'
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(files.items()):
        raw=p.read_bytes();z.writestr(name,raw);manifest['files'].append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
    z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    for entry in manifest['files']:assert sha(z.read(entry['path']))==entry['sha256']
record={'archive':str(DEST),'sha256':sha(DEST.read_bytes()),'files':len(files),'integrity_verified':True,
        'time_reduction_percent':acceptance['time_reduction_percent']}
(PROOF/'archive.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False))
