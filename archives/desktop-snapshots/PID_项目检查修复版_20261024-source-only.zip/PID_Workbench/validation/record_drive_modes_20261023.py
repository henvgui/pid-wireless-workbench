"""Record completed verification without initiating another hardware action."""
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
VALIDATION=Path(__file__).parent
TARGET=Path(r'C:\Users\twice\Desktop\STM32PRO\f407')
hardware=VALIDATION/'drive_modes_hardware_20261023'
flashing=VALIDATION/'drive_modes_flash_f407_20261023'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
host,slave,modes,flash=[load(p) for p in (hardware/'upload_host.json',hardware/'upload_slave.json',hardware/'verify_modes.json',flashing/'flash.json')]
assert all(x['ok'] for x in (host,slave,modes,flash))
job=flash['job']
assert job['state']=='succeeded' and job['result']['verified'] and job['result']['start_ack']
assert [t['target']['mode'] for t in modes['tests']]==[1,0]
assert all(not t['target'][k] for t in modes['tests'] for k in ('running','fault','duty_l100','duty_r100','inhibited'))
assert modes['after']['synced'] and not modes['after']['run_request'] and modes['after']['mode']=='straight'
paths=[ROOT/'PID_Shared/PIDLink/src/pid_link_core.h',ROOT/'PID_Shared/PIDLink/src/pid_link_core.cpp',
       ROOT/'PID_Shared/PIDFlash/src/motor_protocol.h',ROOT/'PID_Shared/PIDFlash/src/motor_bridge.cpp',
       ROOT/'ESP32_S3_RGB_Chase/src/host_local_core.cpp',ROOT/'ESP32_S3_RGB_Chase/src/host_local_app.cpp',
       ROOT/'ESP32_S3_RGB_Chase/src/knob_main.cpp',TARGET/'Core/Src/main.c',
       TARGET/'Core/Src/drive_control.c',TARGET/'Core/Src/drive_app.c',TARGET/'Core/Inc/drive_control.h',
       TARGET/'Core/Inc/motor_protocol.h',TARGET/'Core/Src/stm32f4xx_it.c',TARGET/'MDK-ARM/f407.uvprojx']
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
assert hashes[str(TARGET/'Core/Inc/motor_protocol.h')]==hashes[str(ROOT/'PID_Shared/PIDFlash/src/motor_protocol.h')]
assert '<UseExternalTool>0</UseExternalTool>' in (TARGET/'MDK-ARM/f407.uvprojx').read_text(encoding='utf-8')
record={'completed_at':datetime.now(timezone.utc).isoformat(),'backup':r'C:\Users\twice\Desktop\PID_P启停_I模式_修改前备份_20261023.zip',
        'host_sha256':host['firmware_sha256'],'slave_sha256':slave['firmware_sha256'],
        'stm32_job':job['id'],'stm32_sha256':job['result'].get('sha256',job['spec'].get('sha256')),
        'full_readback_verified':True,'start_ack':True,'target_modes_stop_verified':[1,0],
        'parameters_preserved':{k:modes['after'][k] for k in ('p','i','d','step','stream','saved','dirty')},
        'offline_tests_passed':['drive_modes_test','host_local_test','pid_link_core_test','flash_native_test','swd_test','gcc_c99_warnings_as_errors'],
        'source_sha256':hashes,'physical_button_tested':False,'vehicle_motion_tested':False,'automatic_run_sent':False}
(hardware/'acceptance.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:record[k] for k in ('stm32_job','full_readback_verified','start_ack','target_modes_stop_verified','parameters_preserved')},ensure_ascii=False))
