#pragma once
#include "flash_core.h"
namespace pidflash {
void beginHost();
void beginSlave();
void pollHost(uint32_t now);
void pollSlave(uint32_t now);
bool hostCommand(const char* text);
bool hostPending();
bool hostLocked();
bool takeHostReply(char* output,size_t size);
bool targetActive();
struct SwdDiagnostics {
  uint32_t dpidr;
  uint8_t ack,request,step;
  Error error;
};
SwdDiagnostics swdDiagnostics();
struct TargetDiagnostics {
  Error error=Error::Ok;
  uint32_t dpidr=0;
  uint32_t values[15]={};
  uint16_t valid=0;
  uint32_t h1Edges=0,uartAvailable=0;
  bool logging=false;
};
// Snapshot F407 CPU/UART registers. Never erase/program, halt or reset target.
TargetDiagnostics inspectTarget();
// Brief static input-path check, no target reset or clock pulses; restores OE#.
Error checkSwdInput(uint8_t& isolated,uint8_t& internalPullup,uint8_t& targetLevel,bool hold=false);
void releaseSwdInput();
// H1 UART0 is receive-only while a remote log session is open.
bool serialLogging();
} // namespace pidflash
