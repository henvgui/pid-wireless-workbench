#pragma once
#include "stm32_rom.h"

namespace pidflash {
// SWDIO changes direction at each turnaround. The ESP32 adapter must also
// switch the external translator direction; an input GPIO alone is not enough.
class SwdPins {
 public:
  virtual ~SwdPins()=default;
  virtual void output(bool toTarget)=0;
  virtual void data(bool high)=0;
  virtual bool data()=0;
  virtual void clock(bool high)=0;
  virtual void halfPeriod()=0;
  virtual void reset(bool asserted)=0;
  virtual uint32_t now()=0;
  virtual void wait(uint32_t ms)=0;
};
class SwdTarget {
 public:
  virtual ~SwdTarget()=default;
  virtual Error connect()=0;
  virtual Error read32(uint32_t address,uint32_t& value)=0;
  virtual Error write32(uint32_t address,uint32_t value)=0;
  virtual Error start()=0;
  virtual uint32_t now()=0;
  virtual void wait(uint32_t ms)=0;
};
class ArmSwd:public SwdTarget {
 public:
  explicit ArmSwd(SwdPins& pins):pins_(pins) {}
  Error transfer(bool ap,bool read,uint8_t address,uint32_t& value);
  // Attach the debug memory port without resetting or halting the CPU.
  Error attach();
  Error connect() override;
  Error read32(uint32_t address,uint32_t& value) override;
  Error write32(uint32_t address,uint32_t value) override;
  Error start() override;
  uint32_t now() override { return pins_.now(); }
  void wait(uint32_t ms) override { pins_.wait(ms); }
  uint32_t debugPortId=0;
  uint8_t lastAck=0,lastRequest=0,connectStep=0;
 private:
  void bit(bool value);
  void bits(uint32_t value,unsigned count);
  uint32_t readBits(unsigned count);
  void turnaround();
  void lineReset();
  Error put(bool ap,uint8_t address,uint32_t value);
  Error posted(uint8_t address,uint32_t& value);
  Error status();
  SwdPins& pins_;
};
class F407Swd {
 public:
  explicit F407Swd(SwdTarget& target,Target selected=Target::F407VG):target_(target),selected_(selected) {}
  Error program(const uint8_t* image,uint32_t size,Progress progress=nullptr);
  Error start();
  uint16_t deviceId=0,flashKb=0;
 private:
  Error ready(uint32_t timeout);
  Error execute(const uint8_t* image,uint32_t size,Progress progress);
  SwdTarget& target_;
  Target selected_;
  bool verified_=false,unlocked_=false;
};
} // namespace pidflash
