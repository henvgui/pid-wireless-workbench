#include "main.h"
#include "drive_app.h"
#include "drive_control.h"
#include <stdio.h>

extern TIM_HandleTypeDef htim2,htim3,htim4;
extern UART_HandleTypeDef huart1;
static DriveControl drive;
static MotorParser parser;
static uint8_t rx_byte,rx[256],tx[224];
static volatile uint32_t head,tail,rx_fault;
static uint32_t last_status;
static uint16_t last_l,last_r;

static void outputs(void) {
  const int run=drive.status.running!=0;
  __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,drive.status.duty_l100*800U/10000U);
  __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,drive.status.duty_r100*800U/10000U);
  HAL_GPIO_WritePin(GPIOA,Motor_A_AIN1_Pin|Motor_B_BIN1_Pin,run?GPIO_PIN_SET:GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA,Motor_A_AIN2_Pin|Motor_B_BIN2_Pin,GPIO_PIN_RESET);
}
void DriveApp_Begin(void) {
  Drive_Init(&drive); outputs();
  last_l=(uint16_t)__HAL_TIM_GET_COUNTER(&htim4);
  last_r=(uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
  HAL_NVIC_SetPriority(USART1_IRQn,1,0); HAL_NVIC_EnableIRQ(USART1_IRQn);
  /* RX must preempt the speed loop: at 115200 a byte arrives every 87 us. */
  HAL_NVIC_SetPriority(TIM6_DAC_IRQn,2,0);
  if(HAL_UART_Receive_IT(&huart1,&rx_byte,1)!=HAL_OK) Error_Handler();
}
void DriveApp_Tick(void) {
  uint16_t l=(uint16_t)__HAL_TIM_GET_COUNTER(&htim4);
  uint16_t r=(uint16_t)__HAL_TIM_GET_COUNTER(&htim3);
  Drive_Tick(&drive,HAL_GetTick(),(int16_t)(l-last_l),(int16_t)(r-last_r),l,r);
  last_l=l; last_r=r; outputs();
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart) {
  uint32_t next;
  if(uart->Instance!=USART1) return;
  next=(head+1U)&255U;
  if(next==tail) rx_fault=1;
  else { rx[head]=rx_byte; __DMB(); head=next; }
  if(HAL_UART_Receive_IT(uart,&rx_byte,1)!=HAL_OK) rx_fault=1;
}
void HAL_UART_ErrorCallback(UART_HandleTypeDef *uart) {
  if(uart->Instance==USART1) rx_fault=1;
}
void DriveApp_Poll(void) {
  uint32_t key,now=HAL_GetTick();
  unsigned budget=256;
  if(rx_fault) {
    key=__get_PRIMASK(); __disable_irq();
    Drive_StopFault(&drive,MOTOR_FAULT_LINK); outputs();
    HAL_UART_AbortReceive(&huart1); head=tail=0; parser.size=0; rx_fault=0;
    if(HAL_UART_Receive_IT(&huart1,&rx_byte,1)!=HAL_OK) rx_fault=1;
    __set_PRIMASK(key);
  }
  while(tail!=head && budget--) {
    uint8_t frame[MOTOR_STATUS_SIZE],byte=rx[tail];
    size_t n;
    MotorCommand command;
    __DMB(); tail=(tail+1U)&255U;
    n=MotorProto_Feed(&parser,byte,frame);
    if(n==MOTOR_COMMAND_SIZE && MotorProto_DecodeCommand(frame,n,&command)) {
      key=__get_PRIMASK(); __disable_irq();
      Drive_Apply(&drive,&command,now); outputs();
      __set_PRIMASK(key);
    }
  }
  if((uint32_t)(now-last_status)>=100U && huart1.gState==HAL_UART_STATE_READY) {
    MotorStatus status;
    int count;
    key=__get_PRIMASK(); __disable_irq();
    Drive_Status(&drive,now,&status);
    __set_PRIMASK(key);
    MotorProto_Encode(&status,2,MOTOR_STATUS_SIZE,tx);
    /* Preserve a readable log line after each self-delimiting binary status. */
    count=snprintf((char*)tx+MOTOR_STATUS_SIZE,sizeof(tx)-MOTOR_STATUS_SIZE,
      "\r\nMODE=%s RUN=%lu T=%lu,%lu RPM=%lu,%lu PWM=%lu,%lu FAULT=%lu\r\n",
      status.mode?"S":"STR",(unsigned long)status.running,
      (unsigned long)status.target_l100,(unsigned long)status.target_r100,
      (unsigned long)status.speed_l100,(unsigned long)status.speed_r100,
      (unsigned long)status.duty_l100,(unsigned long)status.duty_r100,(unsigned long)status.fault);
    if(count<0 || (size_t)count>=sizeof(tx)-MOTOR_STATUS_SIZE) count=0;
    if(HAL_UART_Transmit_IT(&huart1,tx,(uint16_t)(MOTOR_STATUS_SIZE+count))==HAL_OK) last_status=now;
  }
}
