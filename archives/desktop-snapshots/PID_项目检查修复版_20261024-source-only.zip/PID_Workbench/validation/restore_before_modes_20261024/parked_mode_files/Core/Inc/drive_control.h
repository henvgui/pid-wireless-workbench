#ifndef DRIVE_CONTROL_H
#define DRIVE_CONTROL_H
#include "motor_protocol.h"

/* Output-shaft encoder counts/revolution; adjust for a different gearbox. */
#define DRIVE_COUNTS_PER_REV 1061.268f
#define DRIVE_COMMAND_TIMEOUT_MS 500U
#define DRIVE_S_PERIOD_MS 6000U
#define DRIVE_S_DEPTH 0.30f
#define DRIVE_RAMP_RPM_PER_SECOND 150.0f

typedef struct {
  MotorCommand command;
  MotorStatus status;
  uint32_t received_at, tick_at, phase_ms, stall_ms[2];
  uint32_t retired[4], retired_index;
  float integral[2], previous_speed[2], target[2];
  uint8_t must_stop, received, ticked;
} DriveControl;

void Drive_Init(DriveControl *drive);
int Drive_Apply(DriveControl *drive, const MotorCommand *command, uint32_t now);
void Drive_StopFault(DriveControl *drive, uint32_t fault);
void Drive_Tick(DriveControl *drive, uint32_t now, int16_t delta_l, int16_t delta_r,
                uint16_t encoder_l, uint16_t encoder_r);
void Drive_Status(const DriveControl *drive, uint32_t now, MotorStatus *status);
#endif
