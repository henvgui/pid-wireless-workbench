#include "drive_control.h"
#include <math.h>

static float clamp(float value, float low, float high) {
  return value<low?low:value>high?high:value;
}
static void stop(DriveControl *d) {
  unsigned i;
  d->status.running=0;
  d->status.target_l100=d->status.target_r100=0;
  d->status.duty_l100=d->status.duty_r100=0;
  d->phase_ms=0;
  for(i=0;i<2;i++) d->integral[i]=d->target[i]=0, d->stall_ms[i]=0;
}
void Drive_Init(DriveControl *d) {
  memset(d,0,sizeof(*d)); d->must_stop=1;
  d->status.app=MOTOR_APP_ID; d->status.fault=MOTOR_FAULT_WAIT_STOP;
}
void Drive_StopFault(DriveControl *d, uint32_t fault) {
  stop(d); d->must_stop=1; d->status.fault|=fault|MOTOR_FAULT_WAIT_STOP;
}
int Drive_Apply(DriveControl *d, const MotorCommand *c, uint32_t now) {
  unsigned i;
  if(!MotorProto_CommandValid(c)) return 0;
  if(c->session!=d->command.session) {
    /* A new sender must first prove STOP. Old retired sessions cannot return. */
    if(c->run) return 0;
    for(i=0;i<4;i++) if(d->retired[i]==c->session) return 0;
    if(d->command.session) d->retired[d->retired_index++%4]=d->command.session;
    stop(d); d->must_stop=1;
  } else {
    if((int32_t)(c->sequence-d->command.sequence)<=0) return 0;
    if((int32_t)(c->request-d->command.request)<0) return 0;
    if(d->received && (uint32_t)(now-d->received_at)>DRIVE_COMMAND_TIMEOUT_MS)
      Drive_StopFault(d,MOTOR_FAULT_LINK);
    if(c->mode!=d->command.mode && c->run) Drive_StopFault(d,MOTOR_FAULT_WAIT_STOP);
  }
  d->command=*c; d->received=1; d->received_at=now;
  d->status.session=c->session; d->status.sequence=c->sequence;
  d->status.revision=c->revision; d->status.request=c->request;
  d->status.p100=c->p100; d->status.i100=c->i100; d->status.d100=c->d100;
  d->status.limit100=c->limit100; d->status.mode=c->mode;
  if(!c->run) {
    stop(d); d->must_stop=0; d->status.fault=0;
  } else if(!d->must_stop) d->status.running=1;
  return 1;
}
void Drive_Tick(DriveControl *d, uint32_t now, int16_t dl, int16_t dr,
                uint16_t el, uint16_t er) {
  float dt, speed[2], desired[2], duty[2]={0,0}, wave=0;
  uint32_t elapsed=d->ticked?(uint32_t)(now-d->tick_at):10U;
  unsigned i;
  d->tick_at=now; d->ticked=1;
  if(elapsed<5U || elapsed>30U) Drive_StopFault(d,MOTOR_FAULT_TIMING);
  if(!d->received || (uint32_t)(now-d->received_at)>DRIVE_COMMAND_TIMEOUT_MS)
    Drive_StopFault(d,MOTOR_FAULT_LINK);
  dt=(float)(elapsed?elapsed:10U)/1000.0f;
  speed[0]=fabsf((float)dl)*60.0f/(DRIVE_COUNTS_PER_REV*dt);
  speed[1]=fabsf((float)dr)*60.0f/(DRIVE_COUNTS_PER_REV*dt);
  d->status.speed_l100=(uint32_t)(speed[0]*100.0f+0.5f);
  d->status.speed_r100=(uint32_t)(speed[1]*100.0f+0.5f);
  d->status.encoder_l=el; d->status.encoder_r=er;
  if(d->status.running) {
    if(d->command.mode==MOTOR_MODE_S_CURVE)
      wave=DRIVE_S_DEPTH*sinf(6.283185307f*(float)d->phase_ms/(float)DRIVE_S_PERIOD_MS);
    desired[0]=clamp((float)d->command.target_l100/100.0f*(1.0f+wave),0,400);
    desired[1]=clamp((float)d->command.target_r100/100.0f*(1.0f-wave),0,400);
    d->phase_ms=(d->phase_ms+elapsed)%DRIVE_S_PERIOD_MS;
    for(i=0;i<2;i++) {
      float error, next_integral, raw, limit=(float)d->command.limit100/100.0f;
      d->target[i]+=clamp(desired[i]-d->target[i],-DRIVE_RAMP_RPM_PER_SECOND*dt,DRIVE_RAMP_RPM_PER_SECOND*dt);
      error=d->target[i]-speed[i];
      next_integral=clamp(d->integral[i]+(float)d->command.i100/100.0f*error*dt,-limit,limit);
      raw=(float)d->command.p100/100.0f*error+next_integral-
          (float)d->command.d100/100.0f*(speed[i]-d->previous_speed[i])/dt;
      /* Conditional integration prevents wind-up at either output rail. */
      if((raw>=0 && raw<=limit)||(raw>limit && error<0)||(raw<0 && error>0)) d->integral[i]=next_integral;
      duty[i]=clamp(raw,0,limit);
      if(d->target[i]>=20 && duty[i]>=15 && speed[i]<1) d->stall_ms[i]+=elapsed;
      else d->stall_ms[i]=0;
      if(d->stall_ms[i]>=1000U) Drive_StopFault(d,i?MOTOR_FAULT_STALL_R:MOTOR_FAULT_STALL_L);
    }
    if(d->status.running) {
      d->status.target_l100=(uint32_t)(d->target[0]*100.0f+0.5f);
      d->status.target_r100=(uint32_t)(d->target[1]*100.0f+0.5f);
      d->status.duty_l100=(uint32_t)(duty[0]*100.0f+0.5f);
      d->status.duty_r100=(uint32_t)(duty[1]*100.0f+0.5f);
    }
  }
  for(i=0;i<2;i++) d->previous_speed[i]=speed[i];
}
void Drive_Status(const DriveControl *d, uint32_t now, MotorStatus *out) {
  *out=d->status; out->tick_ms=now;
  out->command_age_ms=d->received?(uint32_t)(now-d->received_at):0xFFFFFFFFU;
}
