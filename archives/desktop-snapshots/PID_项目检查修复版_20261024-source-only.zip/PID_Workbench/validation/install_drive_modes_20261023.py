"""Apply bounded CubeMX USER CODE edits; backup ZIP was verified before this script."""
from pathlib import Path
import re
import shutil

OUTPUTS=Path(__file__).resolve().parents[2]
TARGET=Path(r'C:\Users\twice\Desktop\STM32PRO\f407')

def region(text, name, body):
    pattern=r'(/\* USER CODE BEGIN '+re.escape(name)+r' \*/)[\s\S]*?(/\* USER CODE END '+re.escape(name)+r' \*/)'
    text,count=re.subn(pattern,lambda m:m[1]+'\n'+body+'\n'+m[2],text)
    assert count==1,(name,count)
    return text

shutil.copy2(OUTPUTS/'PID_Shared/PIDFlash/src/motor_protocol.h',TARGET/'Core/Inc/motor_protocol.h')
p=TARGET/'Core/Src/main.c'
s=p.read_text(encoding='utf-8')
s=region(s,'Includes','#include "drive_app.h"')
s=region(s,'PV','')
s=region(s,'0','')
s=region(s,'2','''  /* Start with both PWM compares zero; only a fresh host RUN can enable motion. */
  __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,0);
  __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,0);
  if(HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1)!=HAL_OK ||
     HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2)!=HAL_OK ||
     HAL_TIM_Encoder_Start(&htim4,TIM_CHANNEL_ALL)!=HAL_OK ||
     HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_ALL)!=HAL_OK) Error_Handler();
  DriveApp_Begin();
  if(HAL_TIM_Base_Start_IT(&htim6)!=HAL_OK) Error_Handler();''')
s=region(s,'WHILE','''  while (1)
  {
    DriveApp_Poll();''')
s=region(s,'4','''void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if(htim->Instance==TIM6) DriveApp_Tick();
}''')
s=region(s,'Error_Handler_Debug','''  __disable_irq();
  if(htim2.Instance==TIM2) {
    __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_1,0);
    __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,0);
  }
  while(1) {}''')
p.write_text(s,encoding='utf-8')
p=TARGET/'Core/Src/stm32f4xx_it.c'
s=region(p.read_text(encoding='utf-8'),'1','''extern UART_HandleTypeDef huart1;
void USART1_IRQHandler(void) { HAL_UART_IRQHandler(&huart1); }''')
p.write_text(s,encoding='utf-8')
p=TARGET/'MDK-ARM/f407.uvprojx'
s=p.read_text(encoding='utf-8-sig')
anchor='<FileName>main.c</FileName>'
assert s.count(anchor)==1
index=s.index('</File>',s.index(anchor))+len('</File>')
entries=''.join('''
            <File>
              <FileName>'''+name+'''</FileName>
              <FileType>1</FileType>
              <FilePath>../Core/Src/'''+name+'''</FilePath>
            </File>''' for name in ('drive_control.c','drive_app.c'))
s=s[:index]+entries+s[index:]
assert '<UseExternalTool>0</UseExternalTool>' in s
p.write_text(s,encoding='utf-8')
print('Applied STM32 USER CODE integration; ST-Link Download configuration preserved.')
