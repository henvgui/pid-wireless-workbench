"""Archive source, runnable Workbench, exact installed ESP binaries and evidence."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
output=Path.home()/'Desktop/PID_无线串口版_20261024.zip'
assert not output.exists(),'Do not overwrite an existing backup'
manifest={}
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name in ('ESP32_S3_RGB_Chase','ESP32_S3_Slave_Diagnostic','PID_Shared','PID_Workbench'):
        for source in sorted((root/name).rglob('*')):
            if not source.is_file() or any(part in ('.pio','__pycache__','.git') for part in source.relative_to(root).parts):continue
            archive.write(source,source.relative_to(root).as_posix())
    for project,env,label in (('ESP32_S3_RGB_Chase','host_flash','host'),('ESP32_S3_Slave_Diagnostic','slave_flash_psram','slave')):
        manifest[label]={}
        for filename in ('firmware.bin','firmware.elf','bootloader.bin','partitions.bin'):
            source=root/project/'.pio/build'/env/filename
            archive.write(source,'firmware/'+label+'/'+filename)
            manifest[label][filename]=hashlib.sha256(source.read_bytes()).hexdigest()
    archive.writestr('firmware/sha256.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    count=len(archive.namelist())
record=dict(path=str(output),files=count,bytes=output.stat().st_size,sha256=hashlib.sha256(output.read_bytes()).hexdigest(),firmware=manifest)
(root/'PID_Workbench/validation/wireless_serial_20261024/package.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k!='firmware'},ensure_ascii=False))
