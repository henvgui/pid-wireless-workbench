"""Exercise the real local/USB firmware, including NVS across reset; restore prior parameters."""
import json
import subprocess
import sys
import time
from pathlib import Path

import serial
from serial.tools import list_ports

record = {"date": "2026-10-16", "firmware": "host_local", "checks": [], "transactions": []}
port = None
pending = b""
original = saved_original = None


def connect():
    global port, pending
    target = next((p for p in list_ports.comports() if p.vid == 0x303A and p.pid == 0x1001
                   and p.serial_number == "44:1B:F6:8D:10:20"), None)
    if not target:
        raise RuntimeError("Host USB not present")
    record["port"] = target.device
    port = serial.Serial(port=None, baudrate=115200, timeout=.04, write_timeout=2)
    port.dtr = True
    port.rts = False
    port.port = target.device
    port.open()
    pending = b""


def line(deadline):
    global pending
    while time.monotonic() < deadline:
        if b"\n" in pending:
            raw, pending = pending.split(b"\n", 1)
            text = raw.decode("utf-8", errors="strict").strip()
            if text:
                return text
            continue
        pending += port.read(port.in_waiting or 1)
    raise TimeoutError("USB line timeout")


def query(command, kind="state"):
    port.write((command+"\n").encode("ascii"))
    deadline = time.monotonic()+4
    lines = []
    try:
        while time.monotonic() < deadline:
            text = line(deadline)
            lines.append(text)
            if text.startswith("{"):
                value = json.loads(text)
                if value["type"] in (kind, "error"):
                    return value
        raise TimeoutError(command)
    finally:
        record["transactions"].append({"command": command, "lines": lines})


def legacy(command="!status"):
    port.write((command+"\n").encode("ascii"))
    deadline = time.monotonic()+4
    lines = []
    header = None
    knobs = {}
    while time.monotonic() < deadline:
        text = line(deadline)
        lines.append(text)
        fields = dict(x.split("=", 1) for x in text.split() if "=" in x)
        if text.startswith("HOST_PANEL "):
            header = fields
        elif text.startswith("KNOB "):
            knobs[fields["name"]] = fields
        if header and len(knobs) == 4:
            record["transactions"].append({"command": command, "lines": lines})
            return header, knobs
    raise TimeoutError(command)


def check(name, ok):
    record["checks"].append({"name": name, "passed": bool(ok)})
    print(("PASS " if ok else "FAIL ")+name, flush=True)
    if not ok:
        raise AssertionError(name)


def parameters(state):
    return tuple(state[k] for k in ("p", "i", "d", "step"))


def apply(values):
    query("!pid %.2f %.2f %.2f" % values[:3])
    return query("!step %.2f" % values[3])


def restore():
    if original is None:
        return
    query("!stream off")
    if saved_original is not None:
        apply(saved_original)
        query("!save")
    else:
        query("!forget")
    apply(parameters(original))
    query("!stream on")


try:
    connect()
    original = query("!get")
    record["original"] = original
    check("local NVS storage available", original.get("storage") is True)
    if original["saved"]:
        saved_original = parameters(query("!load"))
        apply(parameters(original))
    query("!stream off")
    initial, _ = legacy()
    check("wireless off and local app selected", initial.get("app") == "local_usb" and initial.get("wireless") == "off")
    check("button pins match host PCB", initial.get("run_pin") == "18" and initial.get("save_pin") == "21")
    state = query("!pid 1.25 0.10 2.50")
    check("USB PID set", parameters(state)[:3] == (1.25, .10, 2.50))
    state = query("!step 0.10")
    check("USB STEP set", state["step"] == .10)
    before = parameters(state)
    check("invalid PID rejected", query("!pid 3 4 -1")["type"] == "error")
    check("PID error is atomic", parameters(query("!get")) == before)
    check("invalid STEP rejected", query("!step 0.02")["type"] == "error")
    state = query("!save")
    check("explicit SAVE commits profile", state["saved"] and not state["dirty"])
    state = query("!pid 9 8 7")
    check("changes mark profile dirty", state["dirty"])
    state = query("!load")
    check("LOAD restores saved values", parameters(state) == before and not state["dirty"])
    run = query("!run")
    check("RUN is a request awaiting confirmation", run["run_request"] and not run["ack"] and run["request_id"] > 0)
    check("repeated RUN is idempotent", query("!run")["request_id"] == run["request_id"])
    check("mismatched acknowledgement rejected", query("!ackrun %d 0" % run["request_id"])["type"] == "error")
    check("matching RUN acknowledgement accepted", query("!ackrun %d 1" % run["request_id"])["ack"])
    stop = query("!stop")
    check("STOP supersedes RUN request", not stop["run_request"] and stop["request_id"] != run["request_id"] and not stop["ack"])
    check("stale RUN acknowledgement rejected", query("!ackrun %d 1" % run["request_id"])["type"] == "error")
    check("STOP acknowledgement accepted", query("!ackrun %d 0" % stop["request_id"])["ack"])
    query("!stream on")
    check("USB feedback injection accepted", query("!feedback 2 100 90.5 -0.2", "ok")["type"] == "ok")
    deadline = time.monotonic()+3
    telemetry = None
    while time.monotonic() < deadline:
        text = line(deadline)
        if text.startswith("{"):
            value = json.loads(text)
            if value.get("type") == "telemetry":
                telemetry = value
                break
    check("curve data has source/channel/target/feedback/error/output", telemetry is not None
          and telemetry["source"] == "usb" and telemetry["channel"] == 2 and telemetry["error"] == 9.5
          and abs(telemetry["output"]+.2) < .00001)
    check("non-finite telemetry rejected", query("!feedback 0 nan 1 2")["type"] == "error")
    port.write(b"!get\n"*12)
    deadline = time.monotonic()+5
    replies = 0
    while replies < 12:
        text = line(deadline)
        if text.startswith("{") and json.loads(text).get("type") == "state":
            replies += 1
    check("12 queued USB commands return intact JSON replies", replies == 12)
    first, _ = legacy()
    time.sleep(1.2)
    second, _ = legacy()
    check("RGB color compensation and display remain healthy", second["rgb_dither"] == "1"
          and second["brightness"] == "30" and second["lit_pixels"] == "40"
          and second["oled_error"] == "0" and second["rgb_error"] == "0")
    check("OLED continues refreshing", int(second["oled_frames"]) > int(first["oled_frames"]))
    check("RGB sustains fast refresh", int(second["rgb_sent"])-int(first["rgb_sent"]) >= 200)
    h, knobs = legacy("!knob P")
    h, knobs = legacy("!move cw")
    check("knob path uses restored STEP and emits updated value", knobs["P"]["value"] == "1.35")
    query("!load")
    query("!save")
    device = port.port
    port.close()
    port = None
    reset = subprocess.run([sys.executable, str(Path.home()/'.platformio/packages/tool-esptoolpy/esptool.py'),
                            '--chip', 'esp32s3', '--port', device, '--after', 'hard_reset', 'chip_id'],
                           capture_output=True, text=True, timeout=20,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    record["reset_log"] = reset.stdout+reset.stderr
    check("hardware reset succeeds", reset.returncode == 0)
    time.sleep(.6)
    connect()
    reboot = query("!get")
    check("saved PID/STEP survive reset", parameters(reboot) == before and reboot["saved"] and not reboot["dirty"])
    check("restart never resumes a prior RUN request", not reboot["run_request"] and not reboot["ack"] and reboot["request_id"] == 0)
    restore()
    final = query("!get")
    record["final"] = final
    check("pre-test parameters and saved-profile presence restored", parameters(final) == parameters(original)
          and final["saved"] == original["saved"])
    deadline = time.monotonic()+5
    while True:
        record["final_header"], _ = legacy()
        if record["final_header"]["oled_ack"] == "1" or time.monotonic() >= deadline:
            break
        time.sleep(.2)
    check("OLED and RGB recover after reset", record["final_header"]["oled_ack"] == "1"
          and record["final_header"]["oled_error"] == "0"
          and record["final_header"]["rgb_error"] == "0"
          and record["final_header"]["rgb_failures"] == "0")
    record["passed"] = True
except Exception as exc:
    record["passed"] = False
    record["error"] = repr(exc)
    print("ERROR "+repr(exc), flush=True)
    if port is not None and port.is_open and original is not None:
        try:
            restore()
        except Exception as cleanup_error:
            record["cleanup_error"] = repr(cleanup_error)
finally:
    if port is not None:
        port.close()
    Path(__file__).with_name("host_local_usb_20261016.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
raise SystemExit(0 if record["passed"] else 1)
