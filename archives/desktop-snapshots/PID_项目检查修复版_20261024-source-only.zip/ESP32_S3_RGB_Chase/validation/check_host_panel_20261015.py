"""Verify the uploaded panel via USB. Simulated moves are not physical knob tests."""
import json
import sys
import time
from pathlib import Path

import serial
from serial.tools import list_ports

record = {"date": "2026-10-15", "firmware": "host_panel", "checks": [],
          "transactions": [], "physical_result": "pending"}
port = None


def fields(line):
    return dict(part.split("=", 1) for part in line.split() if "=" in part)


def query(command):
    # Preserve the native USB receive stream instead of purging pending bulk reads.
    time.sleep(.03)
    port.write(command.encode("ascii") + b"\n")
    deadline = time.monotonic() + 3
    pending = b""
    lines = []
    header = None
    knobs = {}
    while time.monotonic() < deadline:
        pending += port.read(max(1, port.in_waiting))
        while b"\n" in pending:
            raw, pending = pending.split(b"\n", 1)
            line = raw.decode("utf-8", errors="replace").strip()
            if not line:
                continue
            lines.append(line)
            if line.startswith("HOST_PANEL "):
                header = fields(line)
                knobs = {}
            elif line.startswith("KNOB name=") and header is not None:
                item = fields(line)
                knobs[item["name"]] = item
            elif line.startswith("ERR "):
                record["transactions"].append({"command": command, "lines": lines})
                return {"error": line}
        if header is not None and len(knobs) == 4:
            result = {"header": header, "knobs": knobs}
            record["transactions"].append({"command": command, "lines": lines})
            return result
    record["transactions"].append({"command": command, "lines": lines})
    raise AssertionError("Missing complete HOST_PANEL response to " + command)


def check(name, condition):
    record["checks"].append({"name": name, "passed": bool(condition)})
    print(("PASS " if condition else "FAIL ") + name, flush=True)
    if not condition:
        raise AssertionError(name)


try:
    target = next((p for p in list_ports.comports() if p.vid == 0x303A and p.pid == 0x1001
                   and p.serial_number == "44:1B:F6:8D:10:20"), None)
    if target is None:
        raise RuntimeError("Host USB not present")
    port = serial.Serial(port=None, baudrate=115200, timeout=.04, write_timeout=2)
    port.dtr = True
    port.rts = False
    port.port = target.device
    port.open()
    time.sleep(.15)
    initial = query("!reset")
    check("boot/reset breathing and shared cursor", initial["header"]["mode"] == "breathing"
          and initial["header"]["display"] == "shared" and initial["header"]["idle_ms"] == "5000")
    check("four initial values", [initial["knobs"][k]["value"] for k in ("P", "I", "D", "STEP")]
          == ["0.00", "0.00", "0.00", "1.00"])
    style = initial["header"].get("rgb_style")
    smooth_transitions = "rgb_transition" in initial["header"]
    manual_rainbow = "rgb_manual_cycle_ms" in initial["header"]
    color_dither = initial["header"].get("rgb_dither") == "1"
    smooth_motion = initial["header"].get("rgb_motion") == "subpixel_spring"
    if smooth_motion:
        check("animation cadence configured", initial["header"].get("rgb_frame_ms") == ("4" if color_dither else "10"))
        check("automatic input reports are compact", initial["header"].get("input_reports") == "compact")
    if color_dither:
        check("dim-gradient compensation enabled", initial["header"]["rgb_dither"] == "1"
              and initial["header"]["brightness_limit"] == "30")
    if "brightness_limit" in initial["header"]:
        check("brightness reduced by 25 percent", initial["header"]["brightness"] == "30"
              and initial["header"]["brightness_limit"] == "30")
        check("brightness above new limit rejected", "error" in query("!brightness 31"))
        limited = query("!brightness 30")
        check("brightness limit accepted", limited["header"]["brightness"] == "30")
    if smooth_transitions:
        check("complement background enabled", initial["header"].get("rgb_background") == "complement")
        check("two-edge defaults retained", all(item["edges_per_step"] == "2"
              for item in initial["knobs"].values()))
    if style in ("breath_flow", "gradient_breath"):
        time.sleep(.25)
        automatic = query("!status")
        check("breathing and flow together", automatic["header"]["flow"] ==
              ("auto" if style=="breath_flow" else "gradient"))
        if style == "breath_flow":
            check("automatic head advances", automatic["header"]["flow_position"]
                  != initial["header"]["flow_position"])
        else:
            check("gradient frames advance", int(automatic["header"]["rgb_sent"])
                  > int(initial["header"]["rgb_sent"]))
        check("automatic motion never adjusts parameters",
              [automatic["knobs"][k]["value"] for k in ("P", "I", "D", "STEP")]
              == ["0.00", "0.00", "0.00", "1.00"])
    for name in ("P", "I", "D"):
        query("!knob " + name)
        moved = query("!move cw")
        check(name + " increments by STEP", moved["knobs"][name]["value"] == "1.00"
              and moved["header"]["mode"] == "comet")
    query("!knob STEP")
    moved = query("!move cw")
    check("STEP increases to 10.00", moved["knobs"]["STEP"]["value"] == "10.00")
    query("!knob P")
    moved = query("!move cw")
    check("P uses new STEP", moved["knobs"]["P"]["value"] == "11.00")
    query("!knob STEP")
    for expected in ("1.00", "0.10", "0.01", "0.01"):
        moved = query("!move ccw")
        check("STEP lower bound / " + expected, moved["knobs"]["STEP"]["value"] == expected)
    query("!knob P")
    moved = query("!move cw")
    check("hundredth precision", moved["knobs"]["P"]["value"] == "11.01")
    check("only one shared position", len({v["position"] for v in moved["knobs"].values()}) == 1)
    rejected = query("!display independent")
    check("four-head mode rejected", "error" in rejected)
    query("!reset")
    query("!knob P")
    active = query("!move cw")
    started = time.monotonic()
    time.sleep(1.3)
    stopped = query("!status")
    check("comet holds position before timeout", stopped["header"]["mode"] == "comet"
          and stopped["knobs"]["P"]["position"] == active["knobs"]["P"]["position"])
    if smooth_transitions:
        check("entry fade settles before timeout", stopped["header"]["rgb_transition"] == "0")
    if manual_rainbow:
        check("manual rainbow eight-second cycle", stopped["header"]["rgb_manual_cycle_ms"] == "8000")
        time.sleep(.3)
        colored = query("!status")
        check("manual hue and frames advance while cursor stays", colored["header"]["rgb_accent_hue_deg"]
              != stopped["header"]["rgb_accent_hue_deg"]
              and colored["knobs"]["P"]["position"] == stopped["knobs"]["P"]["position"]
              and colored["knobs"]["P"]["value"] == stopped["knobs"]["P"]["value"]
              and int(colored["header"]["rgb_sent"]) >= int(stopped["header"]["rgb_sent"])+5)
        if smooth_motion:
            check("manual animation sustains compensation cadence",
                  int(colored["header"]["rgb_sent"])-int(stopped["header"]["rgb_sent"]) >= (60 if color_dither else 20))
            check("stopped visual cursor settles at logical target",
                  int(colored["header"]["rgb_position_milli"]) ==
                  (int(colored["knobs"]["P"]["position"])-1)*1000)
    check("OLED and RGB healthy together", stopped["header"]["oled_ack"] == "1"
          and stopped["header"]["oled_error"] == "0"
          and stopped["header"]["rgb_error"] == "0"
          and stopped["header"]["rgb_failures"] == "0")
    time.sleep(max(0, 5.3 - (time.monotonic() - started)))
    idle = query("!status")
    check("5s timeout; status queries do not postpone it", idle["header"]["mode"] == "breathing")
    check("idle keeps numeric value", idle["knobs"]["P"]["value"] == "1.00")
    if smooth_transitions:
        age = int(idle["header"]["last_input_age_ms"])
        check("return fade tracks idle deadline", idle["header"]["rgb_transition"] ==
              ("1" if 5000 <= age < 5900 else "0"))
    resumed = query("!move ccw")
    check("interaction wakes comet again", resumed["header"]["mode"] == "comet"
          and resumed["knobs"]["P"]["value"] == "0.00")
    if smooth_transitions:
        age = int(resumed["header"]["last_input_age_ms"])
        check("input interrupts return with entry fade", resumed["header"]["rgb_transition"] ==
              ("1" if age < 450 else "0"))
        time.sleep(.65)
        settled = query("!status")
        check("interrupted fade settles with all pixels lit", settled["header"]["rgb_transition"] == "0"
              and settled["header"]["mode"] == "comet" and settled["header"]["lit_pixels"] == "40")
        time.sleep(4.7)
        returning = query("!status")
        time.sleep(.8)
        returned = query("!status")
        check("return finishes without a parameter change", returned["header"]["rgb_transition"] == "0"
              and returned["header"]["mode"] == "breathing"
              and returned["knobs"]["P"]["value"] == returning["knobs"]["P"]["value"] == "0.00")
    query("!reset")
    time.sleep(.35)
    final = query("!status")
    record["final_status"] = final
    check("final breathing + all 40 pixels + working OLED", final["header"]["mode"] == "breathing"
          and final["header"]["lit_pixels"] == "40" and final["header"]["oled_ack"] == "1")
    record["passed"] = True
except Exception as exc:
    record["passed"] = False
    record["error"] = repr(exc)
    print("ERROR " + repr(exc), flush=True)
finally:
    if port is not None:
        port.close()
    Path(__file__).with_name(sys.argv[1] if len(sys.argv)>1 else "host_panel_usb_20261015.json").write_text(
        json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
if not record.get("passed"):
    raise SystemExit(1)
