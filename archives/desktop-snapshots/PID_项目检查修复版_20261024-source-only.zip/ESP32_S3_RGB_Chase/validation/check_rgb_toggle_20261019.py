"""USB RGB power checks; does not simulate or claim a physical STEP press."""
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT.parent / "PID_Shared" / "PIDFlash" / "tools"))
from flash_stm32 import Link


def fields(line):
    return dict(item.split("=", 1) for item in line.split() if "=" in item)


def status(link, command="!status"):
    link.serial.write((command + "\n").encode("ascii"))
    end = time.monotonic() + 6
    header, knobs = None, {}
    while time.monotonic() < end:
        if b"\n" not in link.buffer:
            link.buffer += link.serial.read(link.serial.in_waiting or 1)
            continue
        raw, link.buffer = link.buffer.split(b"\n", 1)
        line = raw.decode("utf-8", errors="replace").strip()
        if line.startswith("ERR "):
            raise RuntimeError(line)
        if line.startswith("HOST_PANEL "):
            header, knobs = fields(line), {}
        elif header is not None and line.startswith("KNOB "):
            item = fields(line)
            knobs[item["name"]] = item
        if header and len(knobs) == 4:
            return {"header": header, "knobs": knobs}
    raise TimeoutError("Missing complete response to " + command)


record = {"physical_STEP_test": "not performed by this script", "checks": []}
path = ROOT / "validation" / "step_rgb_toggle_usb_20261019.json"
link, initial_state, initial_header = None, None, None


def check(name, passed):
    record["checks"].append({"name": name, "passed": bool(passed)})
    print(("PASS " if passed else "FAIL ") + name, flush=True)
    if not passed:
        raise AssertionError(name)


try:
    link = Link()
    initial_state = link.query("!get", "state")
    link.query("!stream off", "state")
    initial_header = status(link)
    h = initial_header["header"]
    record["before"] = {"state": initial_state, "status": initial_header}
    check("new firmware and 2-second STEP gesture", h.get("version") == "20261019" and h.get("step_hold_ms") == "2000")
    check("RGB enabled at boot", h.get("rgb_enabled") == "1")
    check("OLED and persistent RGB driver healthy", h.get("oled_ack") == "1" and h.get("oled_error") == "0" and h.get("rgb_error") == "0")
    status(link, "!rgb off")
    time.sleep(.05)
    off = status(link)
    record["off"] = off
    check("off sends all-black output", off["header"]["rgb_enabled"] == "0" and off["header"]["lit_pixels"] == "0")
    check("configured brightness preserved while off", off["header"]["brightness"] == h["brightness"])
    status(link, "!rgbtest on")
    time.sleep(.05)
    test_off = status(link)
    record["diagnostic_while_off"] = test_off
    check("diagnostic pattern cannot override power-off", test_off["header"]["rgb_test"] == "1" and test_off["header"]["lit_pixels"] == "0")
    status(link, "!rgb toggle")
    time.sleep(.05)
    on = status(link)
    record["on"] = on
    check("toggle restores all 40 RGB outputs", on["header"]["rgb_enabled"] == "1" and on["header"]["lit_pixels"] == "40")
    status(link, "!rgbtest off")
    time.sleep(.05)
    final_header = status(link)
    final_state = link.query("!get", "state")
    record["after"] = {"state": final_state, "status": final_header}
    check("original animation restored", final_header["header"]["rgb_test"] == "0" and final_header["header"]["rgb_enabled"] == "1")
    check("PID and STEP values unchanged", all(final_state[k] == initial_state[k] for k in ("p", "i", "d", "step")))
    check("USB commands do not fake physical holds", final_header["header"]["step_holds"] == h["step_holds"])
    check("wireless and OLED remain healthy", final_state["link_online"] and final_state["synced"] and final_header["header"]["oled_ack"] == "1")
    record["passed"] = True
except Exception as error:
    record.update(passed=False, error=str(error))
    raise
finally:
    if link is not None:
        try:
            if initial_header is not None:
                status(link, "!rgbtest " + ("on" if initial_header["header"]["rgb_test"] == "1" else "off"))
                status(link, "!rgb " + ("on" if initial_header["header"]["rgb_enabled"] == "1" else "off"))
            if initial_state is not None:
                link.query("!stream " + ("on" if initial_state["stream"] else "off"), "state")
        finally:
            link.close()
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
