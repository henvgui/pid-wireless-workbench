"""Read physical knob counters without simulating or changing knob state."""
import json
import time
from pathlib import Path

import serial
from serial.tools import list_ports

result = {"date": "2026-10-15", "firmware": "knob_encoder_rmt",
          "samples": [], "physical_visual_result": "pending"}
port = None
latest = {}
pending = b""
try:
    print("Waiting for ESP32-S3 native USB (up to 60 seconds)", flush=True)
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        target = next((p for p in list_ports.comports()
                       if p.vid == 0x303A and p.pid == 0x1001
                       and p.serial_number == "44:1B:F6:8D:10:20"), None)
        if target is not None:
            candidate = serial.Serial(port=None, baudrate=115200,
                                      timeout=.05, write_timeout=2)
            candidate.dtr = True
            candidate.rts = False
            candidate.port = target.device
            try:
                candidate.open()
            except serial.SerialException:
                candidate.close()
            else:
                port = candidate
                result["port"] = target.device
                break
        time.sleep(1)
    if port is None:
        result["error"] = "ESP32 native USB not present"
        print(result["error"], flush=True)
    else:
        print("CONNECTED " + port.port, flush=True)
        deadline = time.monotonic() + 90
        next_query = 0
        while time.monotonic() < deadline:
            now = time.monotonic()
            if now >= next_query:
                port.write(b"!status\n")
                next_query = now + 1
            pending += port.read(max(1, port.in_waiting))
            while b"\n" in pending:
                raw, pending = pending.split(b"\n", 1)
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                result["samples"].append(line)
                if line.startswith("KNOB name="):
                    fields = dict(item.split("=", 1) for item in line.split()[1:]
                                  if "=" in item)
                    name = fields["name"]
                    observed = {key: fields[key] for key in
                                ("cw", "ccw", "presses", "raw_edges", "invalid",
                                 "dropped", "position", "color", "a", "b", "sw")}
                    if observed != latest.get(name):
                        latest[name] = observed
                        print(name + " " + json.dumps(observed), flush=True)
                elif line.startswith("KNOB_ENCODER "):
                    if "first_status" not in result:
                        result["first_status"] = line
                        print(line, flush=True)
                    result["last_status"] = line
                else:
                    print(line, flush=True)
        result["last_knobs"] = latest
except Exception as exc:
    result["error"] = repr(exc)
    print("MONITOR ERROR " + repr(exc), flush=True)
finally:
    if port is not None:
        port.close()
    Path(__file__).with_name("knob_physical_20261015.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Monitor closed; result saved", flush=True)
