"""Check display sleep/wake with RGB kept off, then leave both off for listening."""
import json
import time
from pathlib import Path

import serial
from serial.tools import list_ports

target = next((p for p in list_ports.comports() if p.vid == 0x303A and p.pid == 0x1001
               and p.serial_number == "44:1B:F6:8D:10:20"), None)
if target is None:
    raise SystemExit("Host board USB not detected")
port = serial.Serial(port=None, baudrate=115200, timeout=.04, write_timeout=2)
port.dtr = True
port.rts = False
port.port = target.device
pending = b""
transactions = []


def query(command):
    global pending
    port.write(command.encode("ascii") + b"\n")
    deadline = time.monotonic() + 4
    lines = []
    while time.monotonic() < deadline:
        pending += port.read(port.in_waiting or 1)
        while b"\n" in pending:
            raw, pending = pending.split(b"\n", 1)
            line = raw.decode(errors="replace").strip()
            if line:
                lines.append(line)
        if any(x.startswith("HOST_PANEL ") for x in lines) and sum(x.startswith("KNOB ") for x in lines) >= 4:
            break
    transactions.append({"command": command, "lines": lines})
    header = next((x for x in lines if x.startswith("HOST_PANEL ")), "")
    if not header:
        raise RuntimeError("Missing status reply to " + command)
    return dict(item.split("=", 1) for item in header.split() if "=" in item)


def wait_enabled(enabled):
    deadline = time.monotonic()+3
    while time.monotonic()<deadline:
        time.sleep(.12)
        state = query("!status")
        if state.get("oled_enabled") == str(int(enabled)) and state.get("oled_ack") == "1":
            return state
    raise RuntimeError("OLED worker did not apply requested enabled state")


try:
    port.open()
    query("!brightness 0")
    query("!oled on")
    wait_enabled(True)
    query("!oled off")
    sleeping = wait_enabled(False)
    query("!oled on")
    awake = wait_enabled(True)
    query("!oled off")
    before = wait_enabled(False)
    time.sleep(1.2)
    after = query("!status")
finally:
    port.close()

checks = {
    "oled_sleep_applied": sleeping.get("oled_enabled") == "0",
    "oled_wake_restores_refresh": awake.get("oled_enabled") == "1" and awake.get("oled_ack") == "1"
        and int(awake["oled_frames"]) > int(sleeping["oled_frames"]),
    "oled_left_asleep": after.get("oled_enabled") == "0",
    "oled_frames_stopped": before["oled_frames"] == after["oled_frames"],
    "rgb_stays_off_and_paused": after.get("brightness") == "0" and after.get("rgb_paused") == "1"
        and after.get("lit_pixels") == "0" and before["rgb_sent"] == after["rgb_sent"],
    "esp32_still_running": int(after["uptime_ms"]) > int(before["uptime_ms"]),
    "display_and_rgb_no_errors": after.get("oled_error") == "0" and after.get("rgb_error") == "0",
}
result = {"date": "2026-10-16", "action": "OLED sleep and refresh stopped; RGB off/data paused; ESP32 running",
          "checks": checks, "passed": all(checks.values()), "before": before, "after": after,
          "transactions": transactions, "physical_result": "pending"}
Path(__file__).with_name("oled_sleep_noise_check_20261016.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"checks": checks, "after": after}, ensure_ascii=False))
raise SystemExit(0 if result["passed"] else 1)
