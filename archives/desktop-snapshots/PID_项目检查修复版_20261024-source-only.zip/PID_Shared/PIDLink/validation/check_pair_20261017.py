"""Real two-board ESP-NOW validation. Keeps target outputs disabled and restores RAM parameters."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

import serial
from serial.tools import list_ports

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--restore-file', type=Path)
args = parser.parse_args()
record = {'date': '2026-10-17', 'checks': [], 'transactions': []}


class Console:
    def __init__(self, identity):
        self.identity, self.pending, self.port = identity, b'', None
        self.open()

    def open(self):
        deadline = time.monotonic()+8
        while time.monotonic() < deadline:
            target = next((p for p in list_ports.comports() if p.serial_number == self.identity), None)
            if target:
                self.port = serial.Serial(port=None, baudrate=115200, timeout=.05, write_timeout=2)
                self.port.dtr, self.port.rts, self.port.port = True, False, target.device
                try:
                    self.port.open()
                    self.pending = b''
                    return
                except serial.SerialException:
                    self.port.close()
            time.sleep(.1)
        raise RuntimeError('Missing board '+self.identity)

    def close(self):
        if self.port:
            self.port.close()

    def line(self, deadline):
        while time.monotonic() < deadline:
            if b'\n' in self.pending:
                raw, self.pending = self.pending.split(b'\n', 1)
                if raw.strip():
                    return raw.decode('ascii').strip()
            else:
                self.pending += self.port.read(self.port.in_waiting or 1)
        record.setdefault('partial_lines', []).append({'board': self.identity, 'buffer': self.pending.decode('ascii', errors='replace')})
        raise TimeoutError(self.identity+' response timeout')

    def query(self, command, kind):
        self.port.write((command+'\n').encode('ascii'))
        deadline = time.monotonic()+4
        while True:
            line = self.line(deadline)
            if not line.startswith('{'):
                continue
            try:
                value = json.loads(line)
            except ValueError:
                record.setdefault('malformed_lines', []).append({'board': self.identity, 'command': command, 'line': line})
                raise
            record['transactions'].append({'board': self.identity, 'command': command, 'response': value})
            if value.get('type') in (kind, 'error'):
                return value

    def legacy(self, command='!status'):
        self.port.write((command+'\n').encode('ascii'))
        deadline = time.monotonic()+4
        header, knobs = None, []
        while True:
            line = self.line(deadline)
            fields = dict(t.split('=', 1) for t in line.split() if '=' in t)
            if line.startswith('HOST_PANEL '):
                header = fields
            if line.startswith('KNOB '):
                knobs.append(fields)
            if header and len(knobs) == 4:
                return header, knobs


def check(name, passed):
    record['checks'].append({'name': name, 'passed': bool(passed)})
    print(('PASS ' if passed else 'FAIL ')+name, flush=True)
    if not passed:
        raise AssertionError(name)


def wait_for(console, command, kind, predicate, timeout=5):
    deadline = time.monotonic()+timeout
    while time.monotonic() < deadline:
        value = console.query(command, kind)
        if predicate(value):
            return value
        time.sleep(.04)
    raise TimeoutError(command+' condition not reached: '+str(value))


def values(state):
    return tuple(state[k] for k in ('p', 'i', 'd', 'step'))


def echo_one(console):
    console.port.reset_input_buffer(); console.pending = b''
    console.port.write(b'1')
    deadline = time.monotonic()+2
    while time.monotonic() < deadline:
        byte = console.port.read(1)
        if byte and byte not in (b'\r', b'\n'):
            return byte == b'1'
    return False


host = slave = None
original = restore = None
try:
    host = Console('44:1B:F6:8D:10:20')
    slave = Console('44:1B:F6:8D:10:18')
    original = host.query('!get', 'state')
    restore = json.loads(args.restore_file.read_text(encoding='utf-8')) if args.restore_file else original
    record['original'] = original
    host.query('!stream off', 'state')
    linked = wait_for(host, '!link', 'link', lambda v: v.get('synced') is True)
    mirrored = wait_for(slave, '!link', 'link', lambda v: v.get('online') and v.get('valid'))
    check('two identified boards establish encrypted link', linked['ready'] and linked['encrypted']
          and mirrored['encrypted'] and linked['peer_session'] == mirrored['session'])
    check('target outputs remain disabled', slave.query('!status', 'status')['translator_oe'] == 1)
    start = time.monotonic()
    host.query('!pid 1.25 0.10 2.50', 'state')
    desired = host.query('!step 0.10', 'state')
    mirrored = wait_for(slave, '!link', 'link', lambda v: values(v) == (1.25, .10, 2.50, .10)
                        and v['revision'] == desired['revision'])
    record['initial_sync_latency_ms'] = round((time.monotonic()-start)*1000)
    check('PID and STEP reach slave atomically', values(mirrored) == values(desired))
    check('host confirms latest snapshot', wait_for(host, '!link', 'link', lambda v: v['synced'])['synced'])
    host.query('!pid 10000 0 0', 'error')
    check('invalid PID leaves both boards unchanged', values(host.query('!get', 'state')) == values(desired)
          and values(slave.query('!link', 'link')) == values(desired))
    host.legacy('!knob P')
    host.legacy('!move cw')
    wait_for(slave, '!link', 'link', lambda v: v['p'] == 1.35)
    check('knob adjustment path is relayed', host.query('!get', 'state')['p'] == 1.35)
    running = host.query('!run', 'state')
    running = wait_for(host, '!get', 'state', lambda v: v['run_request'] and v['ack'])
    mirrored = wait_for(slave, '!link', 'link', lambda v: v['run_request'] and v['request_id'] == running['request_id'])
    check('RUN acknowledged by real slave', mirrored['request_id'] == running['request_id']
          and running['ack_scope'] == 'slave')
    check('repeated RUN keeps request ID', host.query('!run', 'state')['request_id'] == running['request_id'])
    check('USB cannot forge wireless acknowledgement', host.query('!ackrun 1 1', 'error')['code'] == 'wireless_ack_required')
    host.query('!stop', 'state')
    stopped = wait_for(host, '!get', 'state', lambda v: not v['run_request'] and v['ack'])
    check('STOP supersedes RUN on slave', wait_for(slave, '!link', 'link', lambda v: not v['run_request'])['request_id']
          == stopped['request_id'])
    # Genuine radio interruption, no USB unplug and no target GPIO activation.
    host.query('!run', 'state')
    wait_for(host, '!get', 'state', lambda v: v['run_request'] and v['ack'])
    check('slave radio can be disabled for loss test', not slave.query('!radio off', 'link')['enabled'])
    wait_for(host, '!link', 'link', lambda v: not v['online'], timeout=5)
    lost = host.query('!get', 'state')
    check('link loss cancels RUN and its acknowledgement', not lost['run_request'] and not lost['ack'])
    check('offline RUN is rejected', host.query('!run', 'error')['code'] == 'slave_not_ready')
    check('loss never enables target outputs', slave.query('!status', 'status')['translator_oe'] == 1)
    slave.query('!radio on', 'link')
    wait_for(host, '!link', 'link', lambda v: v['synced'])
    mirrored = wait_for(slave, '!link', 'link', lambda v: v['online'] and not v['run_request'])
    check('reconnect restores parameters without resuming RUN', mirrored['p'] == 1.35 and not mirrored['run_request'])
    # New peer session while RUN is acknowledged must require a fresh user RUN.
    host.query('!run', 'state')
    wait_for(host, '!get', 'state', lambda v: v['run_request'] and v['ack'])
    old_session = slave.query('!link', 'link')['session']
    slave.query('!radio off', 'link'); slave.query('!radio on', 'link')
    wait_for(host, '!get', 'state', lambda v: not v['run_request'] and v['ack'])
    mirrored = wait_for(slave, '!link', 'link', lambda v: v['online'] and not v['run_request'])
    check('peer session restart cancels RUN', mirrored['session'] != old_session)
    # Rapid edits: transport coalesces to latest state instead of accumulating stale parameters.
    for n in range(30):
        desired = host.query('!pid %.2f 0.20 1.50' % (2+n/100), 'state')
    mirrored = wait_for(slave, '!link', 'link', lambda v: values(v) == values(desired) and v['revision'] == desired['revision'])
    check('rapid changes converge to latest complete snapshot', values(mirrored) == values(desired))
    header1, _ = host.legacy()
    time.sleep(1.2)
    header2, _ = host.legacy()
    check('host RGB color compensation and OLED survive radio', header2['oled_ack'] == '1' and header2['oled_error'] == '0'
          and header2['rgb_dither'] == '1' and header2['rgb_error'] == '0' and header2['rgb_failures'] == '0'
          and int(header2['oled_frames']) > int(header1['oled_frames']))
    fps = (int(header2['frames'])-int(header1['frames']))*1000/(int(header2['uptime_ms'])-int(header1['uptime_ms']))
    record['host_rgb_fps'] = fps
    check('host RGB maintains smooth refresh', fps > 180)
    check('host reports wireless application', header2['app'] == 'host_wireless' and header2['wireless'] == 'espnow')
    # Hardware reset checks full application startup and fresh challenge exchange.
    host.query('!run', 'state')
    wait_for(host, '!get', 'state', lambda v: v['run_request'] and v['ack'])
    old_session = slave.query('!link', 'link')['session']
    slave_port = slave.port.port; slave.close()
    esptool = Path.home()/'.platformio/packages/tool-esptoolpy/esptool.py'
    completed = subprocess.run([sys.executable, str(esptool), '--chip', 'esp32s3', '--port', slave_port,
                                'chip_id'], capture_output=True, text=True, errors='replace', timeout=25)
    record['slave_reset_log'] = completed.stdout+completed.stderr
    check('actual slave reset completes', completed.returncode == 0)
    slave.open()
    wait_for(host, '!link', 'link', lambda v: v['synced'], timeout=8)
    mirrored = wait_for(slave, '!link', 'link', lambda v: v['online'] and not v['run_request'])
    check('slave reboot resyncs without resuming RUN', mirrored['session'] != old_session
          and not host.query('!get', 'state')['run_request'])
    check('slave startup keeps translators disabled', slave.query('!status', 'status')['translator_oe'] == 1)
    # Native USB data still works while RF is active.
    check('slave ordinary echo works with radio', echo_one(slave))
    check('host ordinary echo works with radio', echo_one(host))
    record['final_link'] = host.query('!link', 'link')
    record['passed'] = True
except Exception as exc:
    record['passed'] = False; record['error'] = repr(exc)
    print('ERROR '+repr(exc), flush=True)
finally:
    if slave and slave.port.is_open:
        try:
            slave.query('!radio on', 'link'); slave.query('!auto', 'status')
        except Exception as exc:
            record['slave_cleanup_error'] = repr(exc)
    if host and host.port.is_open and restore:
        try:
            host.query('!stop', 'state')
            host.query('!pid %.2f %.2f %.2f' % values(restore)[:3], 'state')
            host.query('!step %.2f' % restore['step'], 'state')
            wait_for(host, '!link', 'link', lambda v: v['synced'])
            host.query('!stream '+('on' if restore.get('stream', True) else 'off'), 'state')
            record['restored'] = host.query('!get', 'state')
            check('prior RAM parameters restored; RUN stays stopped', values(record['restored']) == values(restore)
                  and not record['restored']['run_request'])
        except Exception as exc:
            record['cleanup_error'] = repr(exc); record['passed'] = False
    if host: host.close()
    if slave: slave.close()
    Path(__file__).with_name('pair_result_20261017.json').write_text(json.dumps(record,indent=2)+'\n', encoding='utf-8')
raise SystemExit(0 if record['passed'] else 1)
