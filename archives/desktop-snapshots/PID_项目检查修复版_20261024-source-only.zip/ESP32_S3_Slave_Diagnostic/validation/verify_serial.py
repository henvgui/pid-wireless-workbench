"""Verify the installed slave diagnostic firmware; does not upload or enable target outputs."""
import argparse
import json
import time
from pathlib import Path

import serial

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--port', required=True, help='Explicit slave USB or UART0 adapter COM port')
args = parser.parse_args()
record = {'port': args.port, 'firmware': 'slave_diagnostic', 'checks': [], 'transactions': []}
pending = b''
port = serial.Serial(port=None, baudrate=115200, timeout=.05, write_timeout=2)
port.dtr, port.rts, port.port = True, False, args.port
verified = False


def receive(deadline):
    global pending
    while time.monotonic() < deadline:
        if b'\n' in pending:
            line, pending = pending.split(b'\n', 1)
            if line.strip():
                return json.loads(line.decode('ascii'))
        else:
            pending += port.read(port.in_waiting or 1)
    raise TimeoutError('No complete JSON response')


def query(command, kind):
    port.write((command+'\n').encode('ascii'))
    deadline = time.monotonic()+4
    while True:
        result = receive(deadline)
        record['transactions'].append({'command': command, 'result': result})
        if result.get('type') == kind or result.get('type') == 'error':
            return result


def check(name, passed):
    record['checks'].append({'name': name, 'passed': bool(passed)})
    print(('PASS ' if passed else 'FAIL ')+name, flush=True)
    if not passed:
        raise AssertionError(name)


try:
    port.open()
    info = query('!info', 'info')
    check('correct diagnostic firmware', info.get('firmware') == 'slave_diagnostic')
    verified = True
    check('ESP32-S3 and 16MB Flash', info['chip'] == 'ESP32-S3' and info['flash_bytes'] == 16777216)
    check('radio and target outputs disabled', info['radio'] == 'off' and info['target_outputs'] == 'disabled')
    pins = query('!pins', 'pins')
    check('slave RGB and OE use separate correct GPIOs', pins['rgb'] == 38 and pins['oe_disable'] == 47)
    first = query('!ping', 'pong')
    second = query('!ping', 'pong')
    check('PING responds and sequence increases', second['seq'] > first['seq'] and first['boot_id'] == second['boot_id'])
    for color in ((255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 255)):
        state = query('!rgb %d %d %d' % color, 'status')
        check('RGB command '+str(color), state['rgb'] == list(color) and state['rgb_mode'] == 'solid')
    state = query('!off', 'status')
    check('RGB off', state['rgb'] == [0, 0, 0])
    state = query('!rgb 256 0 0', 'error')
    check('out-of-range RGB rejected', state['type'] == 'error')
    state = query('!status', 'status')
    check('invalid RGB did not change state', state['rgb'] == [0, 0, 0])
    query('!auto', 'status')
    port.write(b'!ping\n'*12)
    sequence = [receive(time.monotonic()+4) for _ in range(12)]
    check('12 queued queries remain intact', all(s['type'] == 'pong' for s in sequence)
          and all(sequence[i]['seq']+1 == sequence[i+1]['seq'] for i in range(11)))
    query('!'+'x'*200, 'error')
    state = query('!ping', 'pong')
    check('overlong command recovers', state['type'] == 'pong')
    query('!watch on', 'status')
    states = [receive(time.monotonic()+3) for _ in range(3)]
    check('watch reports continuing execution', all(s['type'] == 'status' for s in states)
          and len({s['boot_id'] for s in states}) == 1
          and states[0]['uptime_ms'] < states[1]['uptime_ms'] < states[2]['uptime_ms']
          and states[-1]['loops'] > states[0]['loops'])
    check('RGB driver healthy and translators disabled', states[-1]['rgb_error'] == 0
          and states[-1]['rgb_failures'] == 0 and states[-1]['rgb_frames'] > states[0]['rgb_frames']
          and states[-1]['translator_oe'] == 1)
    query('!watch off', 'status')
    port.reset_input_buffer()
    pending = b''
    port.write(b'1')
    check('ordinary 1 echo', port.read(1) == b'1')
    port.write(b'!ping')
    state = receive(time.monotonic()+4)
    check('unfinished command times out', state.get('code') == 'command_timeout')
    check('timeout recovers', query('!ping', 'pong')['type'] == 'pong')
    record['passed'] = True
except Exception as exc:
    record['passed'] = False
    record['error'] = repr(exc)
    print('ERROR '+repr(exc), flush=True)
finally:
    if port.is_open:
        if verified:
            try:
                query('!watch off', 'status')
                query('!auto', 'status')
            except Exception as exc:
                record['cleanup_error'] = repr(exc)
                record['passed'] = False
        port.close()
    Path(__file__).with_name('serial_result.json').write_text(
        json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
raise SystemExit(0 if record['passed'] else 1)
