#pragma once
#include "host_ui.h"

namespace hostapp {
struct Status {
  bool storage, saved, dirty, runRequested, runAcknowledged;
  uint32_t runRequest, revision;
  uint8_t mode;
};
void begin(hostui::Controller& ui);
void poll(uint32_t now);
void encoderPress(uint8_t knob, uint32_t now);
bool handleCommand(const char* text, uint32_t now);
bool canAcceptCommand();
bool takeDisplayDirty();
Status status();
}  // namespace hostapp
