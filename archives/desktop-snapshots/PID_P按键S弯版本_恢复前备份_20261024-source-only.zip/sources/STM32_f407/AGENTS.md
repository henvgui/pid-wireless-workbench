# 本工程工作约定

## 2026-10-23 最新功能：P 按键启停、I 按键选择直线/S 弯

已先备份到 `C:/Users/twice/Desktop/PID_P启停_I模式_修改前备份_20261023.zip`，再配套更新 ESP32 主机 `host_flash`、从机 `slave_flash_psram`（20261023.3）和本 F407 工程。主机按下 P 编码器切换 RUN/STOP，按下 I 编码器循环选择直线/主动交替转弯的 S 弯，切换模式时先 STOP，需再次按 P 启动。编码器旋转调参、STEP 长按 RGB 开关与原灯效保留；P/I/D/STEP NVS 保持 0.50/0.20/0/0.01，未覆盖保存值。

当前实际源代码为 `Core/Src/drive_control.c`、`drive_app.c` 和 main.c 的 USER CODE 接入，已经移除旧 main.c 固定 PWM=800 的行为。默认上电直线/停止，H2 UART 115200 8N1 下发模式和 PID，USART1 PA9/PA10 回传 MotorProto v2。命令/状态仍为56/96字节，头部byte6为模式0/1，APP ID=0x3244504D；共享头文件与 `PID_Shared/PIDFlash/src/motor_protocol.h` 保持一致。ESP-NOW 参数帧升级 v2，mode 在byte45，主从必须配套升级。固件烧录协议没有改变。

目标速度默认左右各100 RPM，S弯默认±30%差速、6秒周期，目标加速斜率150 RPM/s；细节在 `Core/Inc/drive_control.h`。500ms无新串口指令、堵转或采样异常会停止，需要 STOP 再 RUN。上电/重连不自动启动。UART IRQ 优先级高于10ms速度环，避免115200接收被运算阻塞。USART1每100ms发送二进制状态及可读文本。

本轮三个工程编译通过，F407 0错误/0警告；新镜像13892字节，SHA256 `700ae955309d5d365f07aebd77917d81d7d8271e57a6f81de37158cd0127ce30`，无线SWD任务 `7e6753886e96cd11f82aaf85` 已 succeeded、verified=true、start_ack=true。用户补接后真实 UART 状态确认 S 模式mode=1/request=4、直线mode=0/request=5，均 running=0、PWM=0/0、fault=0。最终直线STOP，主从synced=true。没有自动RUN，尚未验证实际行驶轨迹或物理P/I按键动作；不能把离线S弯测试当作实车轨迹验收。

验收在 `PID_Workbench/validation/drive_modes_hardware_20261023/verify_modes.json` 与 `drive_modes_flash_f407_20261023/flash.json`。最初接线完成前回传超时，接好后重查通过，没有因此改动烧录算法或尝试解除保护。Keil Download 按钮仍为 ST-Link 有线，保留现有 Utilities 配置。使用说明见同目录 `P_I按键与行驶模式使用说明.md`；下方旧 main.c 状态和旧 MotorProto v1 描述均为历史。

## 2026-10-23 最新验收：更换 F407 后无线烧录通过

用户更换 F407，并明确选择从机 H3 的 SWD 排线验证无线烧录。新目标 ID 为 `0x413`、实读容量 512 KiB、RDP 为 `0xAA`，UID 首字为 `0x0045004A`。当前主从固件无需修改，原工程编译 0 错误/0 警告，8880 字节镜像经主机 USB → ESP-NOW → 从机 SWD 完成写入、完整读回和启动确认：任务 `ccceb936d25638e73bdc59c1`，`verified=true`、`start_ack=true`，传输重试 0 次，任务用时约 12.44 秒。

镜像 SHA256 为 `1796653585af5ce29e3ad0b0e31332ba286ec4065fca4081d602552e925dd9a4`；AXF SHA256 为 `e02d1b39ca72e7119803374496f60efc9482875c35e59c9e34c1c3cad023d5bc`。主机 P/I/D/STEP 和 USB 推送保持不变，RUN 请求保持 false。本次未执行解除读保护；旧目标的 RDP=FF 问题不能套用到新目标。

验收文件在 `C:/Users/twice/Documents/Codex/2026-10-01/pid/outputs/PID_Workbench/validation/verify_replacement_f407_20261023/`。Keil Download 按钮仍保持下节的 ST-Link 有线配置；本轮经 CLI/Keil 适配器单独测试无线通道，没有改回工程的外部下载配置。之后采用哪种下载入口以用户要求为准。

## 2026-10-23 先前要求：停止旧目标修复，恢复有线下载

用户已明确中止本轮无线烧录修复，并要求 Keil 恢复有线烧录。当前 `MDK-ARM/f407.uvprojx` 已从原始备份仅恢复 Utilities 下载配置，使用目标调试器；`f407.uvoptx` 保留 ST-Link / SWD 和 `STM32F4xx_512.FLM`。无线外部下载脚本已停用，原配置备份为 `MDK-ARM/f407.uvprojx.wireless_before_wired_20261023_181010.bak`。本次仅改下载配置，没有执行有线烧录，重新打开工程后生效。

下文无线通道说明和验收为历史记录，不要据此自动切回无线下载、继续本轮修复或重复解除读保护。F407 最近读到 RDP=0xFF；已获授权执行的一次解除尝试只在即时寄存器读回 AA，复位及完整断电后仍为 FF，尚未恢复，不能声称目标已重烧成功。用户取消后未再擦写目标。已开始的 ESP32 从机 USB 更新已安全完成并确认应用启动。若继续处理目标读保护/擦除，先遵循用户后续明确要求。

## 2026-10-23 当前代码与日志测试状态

下面的速度 PID/MotorProto 内容为历史记录；当前用户源码已自行调整，实际以 `Core/Src/main.c` 为准。当前 USART1 为 PA9/TX、PA10/RX、115200/8N1，每约10ms打印 `T=... actual=... PWM=...`，未接入 MotorProto 或主机 STOP 协议；TIM6 当前源码将两路 PWM 固定为800。不能将主机 STOP/从机ACK当成当前目标停机确认。

本轮无线日志测试在副本中仅将 LPWM/RPWM 固定值改为0，保留用户原项目源码，副本在 `C:/Users/twice/Documents/Codex/2026-10-01/pid/outputs/PID_Workbench/validation/serial_f407_test_20261023/`。该测试镜像已烧入目标并完整读回、启动确认；原工程后续 Download 会重新安装原来的PWM行为，不应把临时测试副本误当成用户已修改的源项目。

新增日志链路：STM32 PA9 → 从机 H1 第2脚RX/GPIO44，GND共地，H1 TX留空。电脑在PID工作台「03串口日志」接收；H2目标串口与H3 SWD保留。真实采集9492字节，内容含PWM=0,0，本轮无gap/dropped/UART错误；这只表示本轮应用日志和对应测试源码，不是示波器PWM测量。详见 `C:/Users/twice/Desktop/PID项目使用手册/无线串口日志使用说明.md`。

## 用户授权与任务范围

用户于 2026-10-19 明确要求：“阅读这个手册，以后自己烧录”。

后续本工程固件代码或配置修改并编译通过后，按下述流程自主完成烧录和校验，无需再次询问是否烧录。用户若明确要求只编译、暂不烧录或采用其他流程，以最新要求为准。只阅读文档、解释代码、查看状态时，不触发烧录。

详细手册：[PID项目使用手册_AI版.md](C:/Users/twice/Desktop/PID项目使用手册/PID项目使用手册_AI版.md)。其中示例路径、固件、任务键和验收记录均是参考资料，应结合当前任务使用。本工程烧录自己的 `f407.bin`，不要把手册中的 UART_ECHO 测试镜像烧到目标。

## 工程现状

- 目标为 STM32F407VET6，LQFP100，Flash 512 KiB，链接范围 `0x08000000`～`0x0807FFFF`；主 SRAM 128 KiB。不能选为 VGT6。
- CubeMX 配置为 `f407.ioc`；Keil 工程为 `MDK-ARM/f407.uvprojx`，ARM Compiler 5.06 update 5。用户代码写在 `USER CODE` 区域。
- `MOTOR_SPEED_L(int32_t)` 对应电机 A / TIM2_CH1 / PA0；`MOTOR_SPEED_R(int32_t)` 对应电机 B / TIM2_CH2 / PA1，输入 0～100，控制 PWM 占空比并限幅。
- 当前为双轮速度 PID：上电输出 0，需先 STOP 后 RUN；目标默认左右各 100 RPM，PID 输出上限 50%，方向 IN1 高 / IN2 低。TIM6 每 10 ms 运行速度环，霍尔编码器按 13 PPR × 4 × 20.409=1061.268 计数/输出轴圈换算。减速比暂按用户图片，型号不同时应更改。
- 编码器 A 为 TIM4 / PD12、PD13；编码器 B 为 TIM3 / PB4、PB5。
- 当前 USART1（PA9/TX、PA10/RX，115200、8N1）中断收发控制命令和每 100 ms 的 PID 二进制状态，后接原始编码器文本。主机 P/I/D、RUN/STOP 已由从机串口转发到目标；工作台原 API 的 ACK 仍只标到从机，实际应用结果应读取 STM32 状态。

## 烧录工具与通道

- CLI：`C:/Users/twice/Documents/Codex/2026-10-01/pid/outputs/PID_Workbench/pidctl.cmd`。
- 通道：电脑 → 主机 USB → ESP-NOW → 从机 → SWD → STM32；使用 `--interface swd`、`--chip STM32F407VET6`、`--port auto`。
- 按 USB 序列号识别：主机 `44:1B:F6:8D:10:20`，从机 `44:1B:F6:8D:10:18`。2026-10-19 检查时分别为 COM14、COM18；端口可能变化。目标烧录使用主机端口。
- 从机 H3：DIO/GPIO13 → PA13，CLK/GPIO12 → PA14，NRST/GPIO15 → NRST，VTREF → 目标 3.3V，并共地。保持目标正常供电与 Flash 启动配置。
- 普通 STM32 烧录无需重刷两块 ESP32，也不需要调用主机 SAVE 或 RUN。需要的 STOP 和 USB 推送状态处理按工作台现有实现执行，保持 PID 参数及保存值。

## 每次固件变更后的流程

1. 检查 `capabilities`、`ports`、`jobs` 和 `device --port auto`，确认型号、接口能力、设备状态与硬件任务互斥。不要把历史实板验收当作本次连通性或烧录成功。
2. 编译 Keil 工程，确认通过。已安装 `C:/Keil_v5/UV4/UV4.exe`；命令行构建使用 `-b`（必要时 `-r`），目标工程 `MDK-ARM/f407.uvprojx`，使用隐藏窗口。PID 构建日志 `MDK-ARM/pid_build.log`；不要用旧日志代替当前构建。编辑工程 XML 后保持 UTF-8 无 BOM，否则此版本 Keil 会拒绝导入。
3. 将本次 AXF 导出为 BIN：

   ```powershell
   & 'C:/Keil_v5/ARM/ARMCC/bin/fromelf.exe' --bin --output 'C:/Users/twice/Desktop/STM32PRO/f407/MDK-ARM/f407/f407.bin' 'C:/Users/twice/Desktop/STM32PRO/f407/MDK-ARM/f407/f407.axf'
   ```

4. 通过 CLI `plan --chip STM32F407VET6 --interface swd --port auto --firmware <本次BIN绝对路径>` 预检。只接受从 `0x08000000` 链接的 BIN，最大 512 KiB；初始 SP 应在主 SRAM 范围内。不要提交 HEX、ELF 或手册示例镜像，不得绕过型号和实读容量检查。
5. 为本次烧录意图生成并保存一个新的 `idempotency_key`，连同预检 SHA256、镜像路径记录到工程的 `flash_records/`。随后调用 `flash`，附带上述型号/接口/端口/镜像参数、`--expected-sha256 <plan返回值>`、`--idempotency-key <本次键>`。可使用 `--wait` 或提交后按任务 ID 查询。
6. 超时后查询原任务，或以完全相同的请求和键重试；不要换键重复擦写。若已有硬件任务，先等待并检查其终态。确认原因并决定发起新操作时才生成新键。
7. 烧录成功必须同时满足任务 `state=succeeded`、`result.verified=true`、`result.start_ack=true`。SWD 模式下 `go_ack=false` 正常；外层 `ok=true` 不是烧录成功判据。保存任务 ID、固件 SHA256 和校验结果，向用户报告实际结果。

## 串口与验证边界

用户已明确将编码器回传切换为 USART1。若采用从机 H2 接本工程串口，TX/GPIO17 应接 PA10/USART1_RX，RX/GPIO18 应接 PA9/USART1_TX，并接目标 3.3V 参考及共地。

本工程使用 motor_protocol.h 中的 MP/CRC 速度 PID 帧，没有实现手册 UART_ECHO 应用协议；不要用 `echo` 验证本应用。通过 `tools/motor_pid.py status` 读取目标已应用的参数、目标 RPM、速度、PWM、原始计数和故障，`monitor --seconds 10` 可连续观测且不改变 RUN。`target 100 100` 设置左右 RPM 并等待目标回传确认。

当前共享主从固件还支持 MotorStatus/MotorReply/MotorTarget（Op14～16）。正常运行时从机持续占用 UART 转发命令和解码状态；烧录、旧原始抓取、回显和 SWD 诊断前暂停。不要用不支持 PID 转发的旧 ESP 固件覆盖。主机参数、STEP 和 USB 推送设置需保留，不自行 SAVE。结束验证保持 STOP，并通过目标状态确认 PWM 为 0。

通信超过 500 ms 无新命令、采样间隔异常或持续 1 秒无编码器反馈会停机锁定；需 STOP 再 RUN。无反馈保护条件为目标≥20 RPM 且输出≥15%。不得把仅静态计数、RUN 状态或虚拟模型测试当作真实电机调稳。详细使用说明见 `速度PID调试说明.md`。

无线日志读取入口：`C:/Users/twice/.platformio/penv/Scripts/python.exe tools/read_encoders.py --seconds 5`（在本工程运行，或使用脚本绝对路径）。主从新增 `!uart read <十六进制操作ID> <50～1000毫秒>`，通过主机 USB / ESP-NOW / 从机 UART 抓取普通文本；单次最多 128 字节，同一操作 ID 重试回放缓存。采集前确认没有其他硬件任务，完成后释放目标接口并恢复 USB 推送，不写主机 NVS。采集结果保存在 `flash_records/encoder_readback_*.json`。

## 已完成的流程检查

2026-10-19 已读取手册，检查工作台能力与主从 USB 身份，将当前 AXF 导出为 8084 字节 BIN，并通过 `plan` 本地预检。这次阅读任务未提交烧录。以后代码变更后必须重新编译、导出及预检，不能复用该次预检代替新固件验证。

同日后续已将应用迁移到 USART1/PA9、PA10，8088 字节固件通过无线 SWD 任务 `5e86561e92b4fcc2ee9d4586` 完整读回校验和复位启动确认。主从日志读取通道已更新，实测读取 44 组完整编码器行，结果为左 65535、右 1，采集期间未变化。重复抓取 ID 回放验证通过，主机 P/I/D/STEP 与 USB 推送设置保留。实测原文和结果保存在 `flash_records/encoder_readback_usart1_20261019.json`；这不能代替电机运动或编码器转动响应验证。

同日速度 PID 版本 12664 字节，SHA256 `7787145472eb2a2a05cf08b569d80594aa648fbeec373e997afa8a555c1179a6`，任务 `3819bce99fe04b800f758abb` verified/start_ack 均 true。主从支持 PID 转发的固件已更新。真实目标状态确认临时 P/I/D=0.20/0.05/0.01、左右目标 80/120 及恢复 100/100、RUN 非零 PWM、两轮计数不动后约 1 秒停止。最终 STOP、PWM=0、故障清除，原参数 0/0/0、STEP=0.01、stream=true 已恢复，未 SAVE。记录 `flash_records/speed_pid_acceptance_20261019.json`。实际电机运动及稳定跟速仍未验证。

同日用户反馈“主机里面PID参数都是0，而且车也跑不了”，按该修正请求已设置并 SAVE 到主机 NVS：P=0.50、I=0.20、D=0、STEP=0.01，LOAD 回读及目标状态确认通过。用户确认电池/VM 已接通、STBY 接高且共地。3 秒实板试转两轮计数连续变化，最高约 87.28/88.00 RPM，无故障；最后 STOP、PWM=0，保留非零增益，左右目标 100 RPM。此次仅改参数、工具和文档，不改 F407 镜像。记录 `flash_records/motor_run_probe_20261019_185953.json`、`pid_zero_fix_params_20261019.json`、`pid_zero_fix_save_20261019.json`、`pid_zero_fix_load_20261019.json`。不要再把参数恢复到旧的全零快照；测试前读取实时状态，结束恢复本次实时参数和目标。起调值并非各负载下最终调稳参数。
