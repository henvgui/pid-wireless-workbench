# 无线烧录提速与 Keil 使用说明

更新日期：2026-10-24。目标 STM32F407VET6 / 512 KiB，主机 USB → ESP-NOW → 从机 H3 SWD → STM32。

## 这次完成了什么

已恢复加入「P 按键启停、I 按键选择直线 / S 弯」之前的三端代码；P、I 按下恢复原来的灯效操作，旋转调参、STEP 长按开关 RGB 等原功能保留。此后仅在原版本上完善无线传输、SWD 校验和 Keil 下载入口。

| 实板任务 | 固件大小 | 任务用时 | 校验 | 自动启动 |
| --- | ---: | ---: | --- | --- |
| 优化前 | 8,880 字节 | 12.205 秒 | 完整读回通过 | 否 |
| 优化后，CLI | 同一镜像 | 9.090 秒 | 完整读回通过 | 否 |
| 优化后，Keil 适配入口 | 同一镜像 | 8.956 秒 | 完整读回通过 | 否 |

比较不含 Keil 编译时间和进度窗收起时间；本次任务耗时减少约 26%，不同固件大小、排线和无线环境下会变化。三次目标镜像 SHA256 均为 `1796653585af5ce29e3ad0b0e31332ba286ec4065fca4081d602552e925dd9a4`。

## 在 Keil 中使用

1. 打开 `C:/Users/twice/Desktop/STM32PRO/f407/MDK-ARM/f407.uvprojx`。如果工程修改前已经打开，先关闭再重新打开，或选择重新加载磁盘版本。
2. 保持 ESP32 主机接电脑 USB、从机与 STM32 供电，H3 的 SWDIO、SWCLK、NRST、VTREF、GND 接线保留。
3. 点击 **Build / F7**，然后点击 **Download**，或菜单 **Flash → Download**。
4. 独立深色进度窗立即出现，显示当前阶段、真实百分比、已处理字节、阶段观测速率和已用时间。无需先打开 PID 工作台，也不会弹出空白终端。
5. 正常下载默认在完整校验后启动程序。成功窗约 0.6 秒自动收起，输出与结果继续保留在 Keil；失败窗提供「打开日志」，不能把未校验或失败任务显示成成功。

**本次验证使用 `--no-run`，目标最后保持暂停。** 原 F407 程序 TIM6 会直接把两路 PWM 写为 800，并不处理主机 STOP / PID 协议；按用户要求原样恢复，没有借此修改电机行为。之后 Keil 正常 Download 默认自动运行该原程序，电机供电接通时会执行原来的输出。

Keil 的单步、断点和变量观察仍使用原有有线调试配置，这次配置的是 Download 烧录入口。当前原工程编译保留已有 4 个 GPIO 枚举类型警告，0 错误；没有为消除历史警告而改动原程序。

## 提速方法和校验

- 固件无线数据块从 128 字节增加到 192 字节，通过能力标志协商；旧主机或旧从机会使用 128 字节。最大无线应用帧为 224 字节，保留在当前 ESP-NOW 的 250 字节兼容范围内。
- 目标 Flash 读回改成按块流水读取，利用 MEM-AP 自动递增和 posted read 减少重复事务；每 1 KiB 边界重新设置地址。仍逐字节比较整个镜像，保留 SWD 奇偶校验、错误状态检查与失败时禁止启动。
- 保持原来的 2 µs SWD 半周期，未靠提高时钟或跳过校验获得速度。
- 日志块仍为 108 字节数据，原始串口抓取与回显保留 128 字节限制；不因固件数据块增大而改变已有日志接口。
- 保留 CRC、ACK、重传、整文件 SHA256、任务键与完整 Flash 读回。无线链路可能丢包，校验和重试负责检测与恢复，无法恢复时返回失败。
- Keil 和 HTTP 任务新增 `work_done`、`work_total`、`phase_started_at` 与 `phase_first_done`；阶段速率来自已观察到的实际进度，并非无线射频速率。旧任务没有这些字段时仍显示百分比。

协议设计参考：[Arm CMSIS-DAP TransferBlock](https://arm-software.github.io/CMSIS-DAP/latest/group__DAP__TransferBlock.html)、[Espressif ESP-NOW 说明](https://github.com/espressif/esp-faq/blob/master/docs/en/application-solution/esp-now.rst)。

## 参数和版本

主机默认环境已设为 `host_flash`，避免以后默认 Upload 覆盖成不含烧录功能的版本；从机 `slave_flash_psram` / `20261024.1`，后台 `2026.10.24.1`。主从参数帧恢复 v1，已取消本次 P/I 行驶模式字段。

升级前主机 RAM 参数是 P=16.00、I=14.00、D=0、STEP=1.00，升级后已恢复，USB stream=true、dirty=true。没有调用 SAVE，原来已保存的 NVS 参数未被覆盖。

## 备份与验收

- 恢复前保留的 P/I 行驶版本：`C:/Users/twice/Desktop/PID_P按键S弯版本_恢复前备份_20261024.zip`。
- 原始恢复来源：`C:/Users/twice/Desktop/PID_P启停_I模式_修改前备份_20261023.zip`。
- 本轮文件、测试与真实任务：`C:/Users/twice/Documents/Codex/2026-10-01/pid/outputs/PID_Workbench/validation/wireless_upgrade_20261024/`。
- 原 Keil 有线配置：`MDK-ARM/f407.uvprojx.before_pid_20261024_123238_890733.bak`。

任务：原通道 `783ea24075710a0ab23de292`；优化后 `e663374bb9c34c84203524b3`；Keil 适配入口 `a4fa298a0af89a6f6d90c179`。均 succeeded、verified=true，且 run=false。未执行解除读保护、整片擦除或自动试车。
