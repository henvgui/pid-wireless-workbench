"""Preserve reviewed sources, compiled candidate and evidence; no deployment."""
import difflib,hashlib,json,sys,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];evidence=root/'PID_Workbench/validation/project_audit_20261024'
verified='--verified' in sys.argv
baseline=Path.home()/'Desktop/PID_无线串口版_20261024.zip'
output=Path.home()/('Desktop/PID_项目修复_实板已验证_20261024.zip' if verified else 'Desktop/PID_项目检查修复版_20261024.zip')
assert not output.exists(),'Existing backup must not be overwritten'
changes=[]
with zipfile.ZipFile(baseline) as old:
    for name in old.namelist():
        if not name.endswith(('.py','.cpp','.h','.cs','.md')) or '/validation/' in name or '/docs/' in name:continue
        source=root/name
        if source.is_file():
            before=old.read(name).decode('utf-8-sig',errors='replace');after=source.read_text(encoding='utf-8-sig')
            if before!=after:changes.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+name,tofile='after/'+name))
(evidence/'changes.diff').write_text(''.join(changes),encoding='utf-8')
manifest={}
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name in ('ESP32_S3_RGB_Chase','ESP32_S3_Slave_Diagnostic','PID_Shared','PID_Workbench'):
        for source in sorted((root/name).rglob('*')):
            if not source.is_file() or any(part in ('.pio','__pycache__','.git') for part in source.relative_to(root).parts):continue
            if source.name in ('PID_Workbench.audit.exe','PID_Workbench.audit.exe.config'):continue
            content=root/'PID_Workbench/PID_Workbench.audit.exe' if not verified and source==root/'PID_Workbench/PID_Workbench.exe' else source
            archive.write(content,source.relative_to(root).as_posix())
    for project,env,label in (('ESP32_S3_RGB_Chase','host_flash','host'),('ESP32_S3_Slave_Diagnostic','slave_flash_psram','slave')):
        manifest[label]={}
        for filename in ('firmware.bin','firmware.elf','bootloader.bin','partitions.bin'):
            source=root/project/'.pio/build'/env/filename
            archive.write(source,'firmware/'+label+'/'+filename)
            manifest[label][filename]=hashlib.sha256(source.read_bytes()).hexdigest()
    archive.writestr('firmware/sha256.json',json.dumps(manifest,indent=2))
    archive.writestr('UPDATE_STATUS.txt',('Installed and physically validated 2026.10.24.3: host/slave ESP updated, backend recovery, UART loopback and interrupted staging recovery passed; unchanged F407 image verified by SWD with no auto-run. ' if verified else 'Reviewed candidate only; not yet deployed. ')+ 'See PID_Workbench/docs/PROJECT_AUDIT_20261024.md.\n')
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    installed=root/('PID_Workbench/PID_Workbench.exe' if verified else 'PID_Workbench/PID_Workbench.audit.exe')
    assert hashlib.sha256(archive.read('PID_Workbench/PID_Workbench.exe')).hexdigest()==hashlib.sha256(installed.read_bytes()).hexdigest()
    count=len(archive.namelist())
record=dict(path=str(output),files=count,bytes=output.stat().st_size,sha256=hashlib.sha256(output.read_bytes()).hexdigest(),firmware=manifest,deployed=verified)
(evidence/'package.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(files=count,bytes=record['bytes'],sha256=record['sha256'],deployed=verified)))
